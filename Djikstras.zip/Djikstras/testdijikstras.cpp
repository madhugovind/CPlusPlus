#include<bits/stdc++.h>
#include <iostream>
#include <fstream>
using namespace std;
 
void error(const char * msg)
{
    cerr << "Error: " << msg << endl;
    exit(-1);
}

class Edge
{
    public:
    int v; 
    int w;
    Edge (int vertex, int weight): v(vertex), w(weight){}
};
 
struct myComparator
{
  bool operator()(const Edge& lhs, const Edge& rhs) const
  {
    return lhs.w < rhs.w;
  }
};

template <class Item>
class PriorityQueue 
{
private:
 
    list<Item> *items; 
    int N;
public:
 
    PriorityQueue(int maxN): items(new list<Item>[maxN]), N(0) {}
    PriorityQueue(const PriorityQueue &); // copy constructor
    PriorityQueue & operator = (const PriorityQueue &); // override 

    // O(1)
    int isEmpty() const
    { 
        return N <= 0; 
    }
 
    // O(1)
    void remove()
    {
        items[--N].pop_back();
    }
    
    // O(1)
    void insert(Item & item)
    { 
        Item * e1 = &item;
        items[N++].push_back(*e1);
    }
   
    // O(1) 
    Item & extractMin()
    {
        return items[N-1].front();
    }

    ~PriorityQueue()
    {
	delete [] items;
    }
};

class Graph
{
    public:
    int size;
    list < Edge > *adj;

    Graph(const char * fileName):size(0), adj(new list<Edge>[0])
    {
        int value, src, dst, cost;
	delete [] adj;
        ifstream in(fileName);
        if (in >> value) 
	{
            size = value;
        }
        else
            error("file not found");
        adj = new list<Edge> [value];
        for ( ; ; )
        {
            if (in >> src >> dst >> cost)
            {
                addEdge(src, dst, cost);
            }
            else
                break;
        }
        in.close();
    }

    Graph(const Graph &); // copy constructor
    Graph & operator = (const Graph &); // override
     
    void addEdge(int u, int v, int w)
    {
        Edge * e1 = new Edge(v,w);
        Edge * e2 = new Edge(u,w);
        adj[u].push_back(*e1);
        adj[v].push_back(*e2);
        delete e2;
        delete e1;
    }
    
    ~Graph()
    {
        delete [] adj;
    }
    
};

void print_path(vector<int> &prev, int v)
{
    if (prev[v] == -1) 
    {
        cout << v;
        return ;
    }
    print_path(prev, prev[v]);
    cout << "->" << v;
}

void printGraph(int size, vector<int> & dist, vector <int> & prev)
{
    cout << "\n Vertex  Cost     Path\n";
    for (int v = 0; v < size; ++v) 
    {
        cout << "  " << setw(3) << v << "     " << setw(2) << dist[v] << "      ";
        print_path(prev, v);
        cout << '\n';
    }
    cout << "\n" << endl;
}

// Dr.Klefstad: O((||V|+|E|)log|V|)
// But my algorithm could be interpreted as O(1) + O(|E|log|V|) = O(|E|log|V|)
// Although different from Dr.Klefstad's explanation, My work is shown below
// and Daniel mentioned on Piazza that a different implmentation is acceptable 
// as long as the the functionalities demonstrate dijkstra's by comparing 
// distances as I do in the second loop by creating my own PriorityQueue 
// and have methods insert, remove, and extractMin but I do them using a 
// queue like data structure with lists so they remain O(1). Daniel 
// mentioned on Piazza we could do int and vector in place of Vertex and 
// Table, respectively.
void dijkstras(Graph & g, int & src, vector<int> & dist, vector <int> & prev)
{
    PriorityQueue<Edge> pq (g.size); // O(1)
    
    Edge * e = new Edge(src, 0); // O(1)
    pq.insert(*e); // O(1)
    delete e; // O(1)
    dist[src] = 0; // O(1)
    
    // O(|E|*log|V|) = O(|E|log|V)
    while (!pq.isEmpty()) // O(|E|) because there are at most E edges in the prioirtyqueue to work with
    {
        int u = pq.extractMin().v; // O(1)
        pq.remove(); // (1)
        list < Edge >::iterator iter; // O(1)
	// O(log|V|*1) = O(log|V|)
        for (iter = g.adj[u].begin(); iter != g.adj[u].end(); ++iter) // O(log|V|) because there can be at most V adjacent Edges to a vertex
        {
            int v = (*iter).v; // O(1)
            int weight = (*iter).w; // O(1)
            if (dist[v] > dist[u] + weight) // O(1)
            {
                dist[v] = dist[u] + weight; // O(1)
                Edge * e = new Edge(v, dist[v]); // O(1)
                pq.insert(*e); // O(1)
                delete e; // O(1)
                prev[v] = u; // O(1)
            }
        }
    }
}

int main()
{
    Graph G("graph.txt");
    vector<int> dist(G.size, INT_MAX);
    vector<int> prev(G.size, -1);
    int source = 0;
    dijkstras(G, source, dist, prev);
    printGraph(G.size, dist, prev);
    return 0;
}
