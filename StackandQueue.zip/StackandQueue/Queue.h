#include <cctype>
#include <string>
#include <fstream>
#include <iostream>
#ifndef QUEUE_H
#define QUEUE_H

using namespace std;

class ContainerUnderflow : public exception
{
	string message;
public:
	ContainerUnderflow(const char * msg):message(msg){}
	// O(1) because simple print in constant time
	void get_msg()
	{
		cout << message << endl;
	}
};

class ContainerOverflow : public exception
{
	string message;
public:
	ContainerOverflow(const char * msg):message(msg){}
	// O(1) because simple print in constant time
	void get_msg()
	{
		cout << message << endl;
	}
};


class Queue
{
public:
       Queue(){}
	// All O(1) because implemented in constant time as not respective of size
	virtual string deque() = 0; // O(1)
	virtual void enque(string s) = 0; // O(1)
	virtual string front() = 0; // O(1)
	virtual bool isEmpty() = 0; // O(1)
	virtual ~Queue(){} 
};
#endif
