#include <cctype>
#include <iostream>
#include "Stack.h"

class ArrayStack : public Stack
{
	int capacity, tp;
	string * buf;
	

       public:
       ArrayStack(int maxSize): capacity(maxSize), tp(0), buf(new string[maxSize]) {}

	// O(1) because simple return after comparison
	// irrespective of size = constant time	
       bool isEmpty()
       {
              return tp<=0;
       }

       // O(1) because simple return after comparison
       // irrespective of size
       bool isFull()
       {
              return tp>=capacity;
       }

       // O(1) because simple boolean check method is (O(1) look above) and throw
       // with setting index value all irrespective of size and happens once 
       void push (string s) throw (ContainerOverflow)
       {
              if(isFull())
                     throw ContainerOverflow("Push on Full Stack");
              buf[tp++] = s;
       }

       // O(1) because simple boolean check method is (O(1) look above) and throw
       // with returning index value all irrespective of size and happens once 
       string pop() throw (ContainerUnderflow)
       {
              if (isEmpty())
                     throw ContainerUnderflow("Pop on Empty Stack");
              return buf[--tp];
       }

       // O(1) because simple boolean check method is (O(1) look above) and throw
       // with returning index value all irrespective of size and happen once 
       string top() throw (ContainerUnderflow)
       {
              if (isEmpty())
                     throw ContainerUnderflow("Top of Empty Stack");
              return buf[tp-1];
       }

       // O(1) simple delete array irrespective of size
       ~ArrayStack()
       {
              delete [] buf;
       }
       
};
