#include <string>
#include <iostream>
#include "Queue.h"

using namespace std;

class LinkedQueue : public Queue
{ 
	struct ListNode
       {
              string info;
              ListNode * next;
              ListNode(string s, ListNode * n): info(s), next(n){}
            
	      // O(N) used in the destructor
	      // while loop traverses through all nodes in list so O(N)
              static void deleteAll(ListNode * l)
              {
                     ListNode* temp = l;
                     while( temp != nullptr ) 
                     {
                            ListNode* next = temp->next;
                            delete temp;
                            temp = next;
                     }
                     l = nullptr;
              }
       };
       
       ListNode * head, * tail;
       
       public:
       LinkedQueue() : head(nullptr), tail(nullptr) {}

       // O(1) because return with a boolean expression
       // irrespective of size
       bool isEmpty()
       {
              return head == nullptr;
       }

       // O(1) simple return irrespective of size
       bool isFull()
       {
              return false;
       }

       // O(1) becaus isEmpty is constant and throw and return all in constant time
       string front() throw (ContainerUnderflow)
       {
              if (isEmpty())
                     throw ContainerUnderflow("Front on Empty Stack");
              return head->info;
       }

       // O(1) because initialization and checking all in constant time irrespective of size
       void enque(string s)
       {
              ListNode * newNode = new ListNode(s, nullptr);
              if (!tail) // if (isEmpty())
                     head = newNode;
              else
                     tail->next = newNode;
              tail = newNode;
       }

       // O(1) because isEmpty is O(1) as explained above and
       // other constant time operations so worst case is O(1)
       string pop() throw (ContainerUnderflow)
       {
              ListNode * t = head;
              head = head->next;
              string s = t->info;
              delete t;
              return s;
       }

       // O(1) because isEmpty is O(1) as explained above and other
       // constant time operations so worst case is O(1)
       string deque() throw (ContainerUnderflow)
       {
              if (isEmpty())
                     throw ContainerUnderflow("Deque on Empty Stack");
              string ret = pop();
              if (!head)
                     tail = nullptr;
              return ret;
       }

       // O(N) because deleteAll is called which is O(N) as described above
       ~LinkedQueue()
       {
              ListNode::deleteAll(head);
       }
};
