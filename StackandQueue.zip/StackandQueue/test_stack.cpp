#include <cctype>
#include <sstream>
#include <string>
#include <fstream>
#include <iostream>
#include "Stack.h"
#include "ArrayStack.h"
#include "LinkedStack.h"

using namespace std;

// while loop is O(N) because must traverse through entire
// list of words and push is O(1) because we 
// implemented all Stack and Queue functions in constant time
// (see explanations there) so N*1 = N therefore O(N) 
void fillAll(Stack& ST, char * infile)
{
       ifstream myfile (infile);
       string word;
       if (myfile.is_open())
	       while ( getline (myfile,word) )
		       ST.push(word);
       else
              cerr << "Cannot open file." << endl;
}

// while loop is O(N) because must traverse through entire
// list of words and pop and top is O(1) because we implemented
// all stack and Queue functions in constant time
// (see explanatins there) so N*1= N therefore O(N)
void emptyAll(Stack& ST, char * outfile)
{
	ofstream out (outfile);
       if (!ST.isEmpty())
       {
       	      cout << endl << ST.top();
              out << ST.pop();
       }
       while (!ST.isEmpty())
       {
       	      cout << endl << ST.top();
              out << endl << ST.pop();
       }
       cout << endl;
}

// O(N) because for loop traverses through entire list as size is stated and instead
// all operations are constant time so N*1 = N therefore O(N)
bool isBalanced(string s)
{
	LinkedStack l;
       for (int i = 0; i < (int) s.size(); i++)
       {
              if (s[i] == '(' or s[i] == '[' or s[i] == '{')
              {
              		stringstream ss;
			string s1;
			ss << s[i];
			ss >> s1;
              		l.push(s1);
              }
              else if (s[i] == ')' or s[i] == ']' or s[i] == '}')
              {
              	     try
                     {
                     	if (l.top()[0] == '(' and s[i] == ')')
                     		l.pop();
                     	else if (l.top()[0] == '[' and s[i] == ']')
                     		l.pop();
                     	else if (l.top()[0] == '{' and s[i] == '}')
                     		l.pop();
                     		
                     }
                     catch(const ContainerUnderflow & ex)
                     {
                     	return false;
                     }
              }
                    
       }
       return l.isEmpty();
}

// O(N) because fillAll, emptyAll and isBalanced is all O(N) as described above
int main( int argc, char * argv [] )
{
	cout << endl;
	
	if ( argc > 3 )
	{
		try
		{
			cout << "Testing ArrayStack:" << endl;
			ArrayStack AS(45500);
			cout << "Filling ArrayStack." << endl;
			fillAll(AS, argv[1]);
			cout << "Susscessfully filled ArrayStack." << endl;
			cout << "Emptying ArrayStack.";
			emptyAll(AS, argv[2]);
			cout << "Susscessfully emptied ArrayStack." << endl;
			
			cout << endl << "Testing LinkedStack:" << endl;
			LinkedStack LS;
			cout << "Filling LinkedStack." << endl;
			fillAll(LS, argv[1]);
			cout << "Susscessfully filled LinkedStack." << endl;
			cout << "Emptying LinkedStack.";
			emptyAll(LS, argv[3]);
			cout << "Susscessfully emptied LinkedStack." << endl << endl;
		
			cout << "Testing isBalanced:" << endl;
			cout << isBalanced("({(())})((([({})])))(((((()([{()}])(()))))))()") <<  " should be true." << endl;
			cout << isBalanced("({(())})((([({})])))(((((()([{()}])(())))))") << " should be false." << endl;
			cout << isBalanced("({(())})((([({})])))(((((()([{()}])(()))))))()])") << " should be false." << endl << endl;
		
			cout << "Testing ArrayStack Exceptions:\n3 exceptions will pop up if you uncomment following three lines" << endl;
			ArrayStack AS2(2);
			for (int i = 0;  i< 3; i++)
			{
				//AS2.push("string");
			}
			ArrayStack AS3(2);
			//AS2.pop();
			//AS2.top();
			
			cout << "Testing LinkedStack Exceptions:\n3 exceptions will pop up if you uncomment following three lines" << endl;
			LinkedStack LS2;
			//LS2.pop();
			//LS2.top();
		}
		catch(ContainerOverflow & ex)
              {
              	ex.get_msg();
              }
              catch(ContainerUnderflow & ex)
              {
              	ex.get_msg();
              }
	}
	else
		cerr << "Enter Valid Input." << endl;

	cout << endl;

	return 0;
}
