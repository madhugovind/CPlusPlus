#include <cctype>
#include <string>
#include <fstream>
#include <iostream>
#ifndef STACK_H
#define STACK_H
#include <exception>

using namespace std;

class ContainerUnderflow : public exception
{
	string message;
public:
	ContainerUnderflow(const char * msg):message(msg){}
	// O(1) because simply prints something in constant time/irrespective of size
	void get_msg()
	{
		cout << message << endl;
	}
};

class ContainerOverflow : public exception
{
	string message;
public:
	ContainerOverflow(const char * msg):message(msg){}
	// O(1) because simple print something in constant time/irrespective of size
	void get_msg()
	{
		cout << message << endl;
	}
};

class Stack
{
public:
       Stack(){}
	// All are implemented in constant time because all irrespective of time and no loops
	virtual string pop() = 0; // O(1)
	virtual void push(string s) = 0; // O(1)
	virtual string top() = 0; // O(1)
	virtual bool isEmpty() = 0; // O(1)
	virtual ~Stack(){}
};
#endif
