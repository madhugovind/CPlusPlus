#include <string>
#include "Queue.h"

using namespace std;

class ArrayQueue : public Queue
{
       int capacity, frnt , rear;
	string * buf;
       
       public:
       ArrayQueue(int maxSize): capacity(maxSize+1), frnt(0), rear(0), buf(new string[maxSize+1]) {}
      
	// O(1) because one simple return after single comparison irrespective of size = constant time 
       bool isEmpty()
       {
              return frnt == rear;
       }
       
	// O(1) because one simple return after single somparison with a couple operations
	// irrespective of size
       bool isFull()
       {
              return (rear+1)%capacity == frnt;
       }
      
	// O(1) because one simple boolean check then throw 
	// ContainerOverflow (see in abstract class why it is O(1))
	// or return of indexing so nothing respective of size
       string front()
       {
              if (isEmpty())
                     throw ContainerUnderflow("Front on Empty Queue");
              return buf[frnt];
       }
      
	// O(1) because one simple boolean check then throw
	// ContainerOverflow (see in abstract class why it is O(1))
	// or setting single index value either way
	// nothing respective of size
       void enque(string s) throw (ContainerOverflow)
       {
              if (isFull())
                     throw ContainerOverflow("Enque on Full Queue");
              buf[rear] = s;
              rear = (rear+1)%capacity;
       }
      
	// O(1) because one simple boolean check then throw
	// ContainerOverflow (see in abstract class why it is O(1))
	// or simple storing and coversion operations twice
	// then return all irrespective of size
       string deque() throw (ContainerUnderflow)
       {
              if (isEmpty())
                     throw ContainerUnderflow("Deque on Empty Queue");
              string ret = buf[frnt];
              frnt = (frnt+1) % capacity;
              return ret;
       }

       // O(1) simple delete irrespective size
       ~ArrayQueue()
       {
              delete [] buf;
       }
};






