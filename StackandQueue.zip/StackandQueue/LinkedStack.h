#include <cctype>
#include <iostream>
#include "Stack.h"

using namespace std;

class LinkedStack : public Stack
{ 
       struct ListNode
       {
              string info;
              ListNode * next;
              ListNode(string s, ListNode * n): info(s), next(n){}
            
	      // O(N) used in destructor
	      // while loop traverses through all nodes in list so O(N) 
              static void deleteAll(ListNode * l)
              {
                     ListNode* temp = l;
                     while( temp != nullptr ) 
                     {
                            ListNode* next = temp->next;
                            delete temp;
                            temp = next;
                     }
                     l = nullptr;
              }
       };

       ListNode * head;
       
       public:
       LinkedStack() : head(nullptr) {}

	// O(1) because return with a boolean expression
	// irrespective of size
	virtual bool isEmpty()
       {
              return head == nullptr;
       }

       // O(1) simple return irrespective of size
       bool isFull()
       {
              return false;
       }

       // O(1) because initialization is irrespective of size
       void push (string s)
       {
              head = new ListNode(s, head);
       }

       // O(1) because isEmpty is O(1) as explained above
       // and other constant time operations so worst case is O(1)
       string pop() throw (ContainerUnderflow)
       {
              if (isEmpty())
                     throw ContainerUnderflow("Pop on Empty Stack");
              ListNode * t = head;
              head = head->next;
              string s = t->info;
              delete t;
              return s;
       }

       // O(1) because isEmpty is constant time and throw and return all in constant time
       string top() throw (ContainerUnderflow)
       {
              if (isEmpty())
                     throw ContainerUnderflow("Top on Empty Stack");
              return head->info;
       }

       // O(N) because deleteAll is O(N)
       ~LinkedStack()
       {
              ListNode::deleteAll(head);
       }
       
};
