#include <cctype>
#include <fstream>
#include <iostream>
#include "Queue.h"
#include "ArrayQueue.h"
#include "LinkedQueue.h"

using namespace std;

// O(N) while loop is O(N) because must traverse through entire list
// of words and enque is O(1) becase we impleneted all Stack and Queue functions in constant time
// (see explanations there) so N*1=N therefore O(N)
void fillAll(Queue& Q, char * infile)
{
	ifstream myfile (infile);
	string word;
       if (myfile.is_open())
	       while ( getline (myfile,word) )
		       Q.enque(word);
       else
              cerr << "Cannot open file." << endl;
}

// O(N) while loop is O(N) because must traverse through entire list
// of words and deque and front are  O(1) becase we impleneted all Stack and Queue functions in constant time
// (see explanations there) so N*1=N therefore O(N)
void emptyAll(Queue& Q, char * outfile)
{
	ofstream out(outfile);
       if (!Q.isEmpty())
       {
       	cout << endl << Q.front();
       	out << Q.deque();
       }
       while (!Q.isEmpty())
       {
       	cout << endl << Q.front();
              out << endl << Q.deque();
       }
       cout << endl;
}

// O(N) because fillAll, emptyAll and isBalanced is all O(N) as described above
int main( int argc, char * argv [] )
{
	cout << endl;
	
	if ( argc > 1 )
	{
		try
		{
			cout << "Testing ArrayQueue:" << endl;
			ArrayQueue AQ(45500);
			cout << "Filling ArrayQueue." << endl;
			fillAll(AQ, argv[1]);
			cout << "Susscessfully filled ArrayQueue." << endl;
			cout << "Emptying ArrayQueue.";
			emptyAll(AQ, argv[2]);
			cout << "Susscessfully emptied ArrayQueue." << endl;
			
			cout << endl << "Testing LinkedQueue:" << endl;
			LinkedQueue LQ;
			cout << "Filling LinkedQueue." << endl;
			fillAll(LQ, argv[1]);
			cout << "Susscessfully filled LinkedQueue." << endl;
			cout << "Emptying LinkedQueue.";
			emptyAll(LQ, argv[3]);
			cout << "Susscessfully emptied LinkedQueue." << endl << endl;
		
			cout << "Testing ArrayQueue Exceptions:\n3 exceptions will pop up if you uncomment following three lines" << endl;
			ArrayQueue AQ2(2);
			for (int i = 0;  i< 3; i++)
			{
				//AQ2.enque("string");
			}
			ArrayQueue AQ3(2);
			//AQ2.deque();
			//AQ2.front();
			
			cout << "Testing LinkedQueue Exceptions:\n3 exceptions will pop up if you uncomment following three lines" << endl;
			LinkedQueue LQ2;
			//LQ2.deque();
			//LQ2.front();
		}
		catch(ContainerOverflow & ex)
              {
              	ex.get_msg();
              }
              catch(ContainerUnderflow & ex)
              {
              	ex.get_msg();
              }
	}
	else
		cerr << "Enter Valid Input." << endl;

	cout << endl;

	return 0;
}
