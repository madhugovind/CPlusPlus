#include <iostream>
#include <fstream>

using namespace std;

struct ListNode
{
     char val;
     ListNode * next;
     ListNode(char c): val(c), next(nullptr){}
     ListNode(char c, ListNode * n): val(c), next(n){} 
     
     // O(N) because has one for loop that traverses from 0 to size N
     static int len(ListNode * l)
     {
          int len = 0;
          for (ListNode * p = l; p != nullptr; p=p->next)
               ++len;
          return len;
     }
    
     // O(1) because just one return statement 
     static ListNode * insert(char c, ListNode *l)
     {
          return new ListNode(c, l);
     }
     
     static void deleteALL(ListNode * n)
          {
               ListNode* temp = n;
               while( temp != nullptr ) 
               {
                    ListNode* next = temp->next;
                    delete temp;
                    temp = next;
               }
               n = nullptr;
          }

     // O(N) because there is one for loop that traverses from 0 to size N 
     static ListNode* copy( ListNode* current )
            {
                 if (current==nullptr)   
                    return nullptr;
                ListNode * newLN = new ListNode(current->val, nullptr);
                    ListNode * result = newLN;
                    for (ListNode * p = current->next; p != nullptr; p = p-> next)
                    {
                         newLN -> next = ListNode::insert( p->val, nullptr);
                         newLN = newLN->next;
                    }
     		   return result;
            }

	static ListNode * append(ListNode * current, ListNode * l)
          {
               if (l == nullptr)
                    return ListNode::copy(current);
               else if (current == nullptr)
                    return ListNode::copy(l);
               
               else
               {
                    ListNode * newLN = new ListNode(current->val, nullptr);
                    ListNode * result = newLN;
                    for (ListNode * p = current->next; p != nullptr; p = p-> next)
                    {
                         newLN -> next = new ListNode( p->val, nullptr);
                         newLN = newLN->next;
                    }
                    newLN->next = ListNode::copy(l);
                    
                    return result;
               }
               
          }	
	
	
     static ListNode * find(char c, ListNode *l)
     {
          for (ListNode * p = l; p!=nullptr; p=p->next)
               if (p->val==c)
                    return p;
          return nullptr;
     }
     static ListNode  * remove (char c, ListNode * l)
     {
          ListNode *p = find(c,l);
          if (p==nullptr)
               return l;
          ListNode *t = p-> next;
          p->val = p->next ->val;
          p->next = p->next->next;
          delete t;
          return l;
     }
};

class MyString
{
     private:
          ListNode * head;
     public:
 
          static void error(const char *s)
          {
               cerr << "Error: " << s << endl;
               throw 1; 
          }
          
	  // O(N) because strToList has one for loop that traverses from 0 to size N
          explicit MyString( const char * s = "")
          {
               if (s==""| s=="\0")
                    head = nullptr;
               else
               {
                    head = strToList(s);
               }
          }
          
          MyString( const MyString & s )
          {
               if (s.head == nullptr)
                    head = nullptr;
               else
               {
                    head = new ListNode(s.head->val);
                    ListNode * current = head;
                    ListNode * newLN = s.head->next;
                    while(newLN !=nullptr)
                    {
                         current->next = new ListNode(newLN->val);
                         current=current->next;
                         newLN=newLN->next;
                    }
                    current->next = nullptr;
                    delete newLN;
               }
          }
	
	// O(N) because there is one for loop that traverses from 0 to size N
	ListNode* strToList(const char *s) const
    	 {
          ListNode * newLN = new ListNode(s[0], nullptr);
          ListNode * result = newLN;
          for (int i=1; s[i] != '\0'; ++i)
          {
               newLN -> next = new ListNode( s[i], nullptr);
               newLN = newLN->next;
          }
          newLN->next = nullptr;
          return result;
          
    	 }

          // O(N) because has one for loop that traverses from 0 to size N 
          int length() const
          {
               return ListNode::len(head);
          }
          
          bool operator == ( const MyString & s ) const
          {
               if (length() != s.length())
                    return false;
               for (ListNode * p = head, *p2 = s.head; p != nullptr; p=p->next, p2 = p2->next)
                    if (p->val != p2->val)
                         return false;
               return true;
          }
          
          MyString & operator = ( const MyString & s )
          {
               ListNode* temp = head;
               while( temp != nullptr ) 
               {
                    ListNode* next = temp->next;
                    delete temp;
                    temp = next;
               }
               head = nullptr;
               if (s.head != nullptr)
               {
                    head = new ListNode(s.head->val);
                    ListNode * current = head;
                    ListNode * newLN = s.head->next;
                    while(newLN !=nullptr)
                    {
                         current->next = new ListNode(newLN->val);
                         current=current->next;
                         newLN=newLN->next;
                    }
                    current->next = nullptr;
                    delete newLN;
               }
          }
          
          int indexOf( char c) const 
          {
               ListNode * ptr = ListNode::find(c, head);
               if (ptr == nullptr)
                    return -1;
               int i = 0;
               for (ListNode * p = ptr; p != nullptr; p=p->next)
               {
                    i++;
               }
               return length()-i;
          }

         // O(N) because one for loop that traverses from 0 to size N 
          char & operator [] ( const int index ) const
          {
               if(index >= length() || index < 0 || head == nullptr)
                    error("Index out of bounds**");
               int i = 0;
               for (ListNode * p = head; p != nullptr; p=p->next, ++i)
                    if (i == index)
                         return p->val;
          }
          
	  // O(N^2) because there are for 2 for loops that traverse from O to size N
          int indexOf( const MyString & pat ) const 
          {
               int len = pat.length();
               if (len==0)
                    return 0;
               
               int index =0, count =0;
               int match = -1;
               for (ListNode * p = head; p != nullptr; p=p->next, ++index)
               {
                    ListNode * s = pat.head;
                    ListNode * n = p;
                    for (count = 0; n!=nullptr && s!=nullptr; n=n->next, s=s->next)
                    {
                         if (n->val == s->val)
                         {
                              if (match == -1)
                                   match = index;
                              ++count;
                         }
                         else
                              match = -1;
                         if (count == len)
                              return match;
                    }
               }
               return -1;
          }
          
          void print( ostream & out ) const
          {
               for (ListNode * p = head; p != nullptr; p=p->next)
               {
                    out << p->val;
               }
          }
          
          void deleteLN(ListNode * n) const
          {
               ListNode* temp = n;
               while( temp != nullptr ) 
               {
                    ListNode* next = temp->next;
                    delete temp;
                    temp = next;
               }
               n = nullptr;
          }
          
          MyString operator + ( const MyString & s ) const
          {
               MyString newS;
               newS.head  = ListNode::append(head, s.head);
               return newS;
               
          }
          
          MyString operator += (const MyString &s)
          {
               ListNode * temp = ListNode::copy(head);
               deleteLN(head);
               head = ListNode::append(temp,s.head);
               deleteLN(temp);
               return *this;
	  }
         
	  //O(N) because there is one for loop that traverses through 0 to size N   
          MyString reverse() const
          {
               MyString newS;
               ListNode * result = nullptr;
               for( ListNode * p = head; p != nullptr; p = p->next)
                    result = new ListNode(p->val, result);
               newS.head = result;
               return newS;
          }
          
          ~MyString()
          {
               ListNode* temp = head;
               while( temp != nullptr ) 
               {
                    ListNode* next = temp->next;
                    delete temp;
                    temp = next;
               }
               head = nullptr;
          }
  
  
  void read( istream & in )
  {
     ListNode * temp = head;
     deleteLN(head);
	char *s = new char[256]();
	in.getline(s, 10000);
	head = strToList(s);
	delete [] s;
  }
  
};
  
MyString copyConstructorTest(MyString l) 
{
     // explicitly calling constructor
     // passing by value
     // passing by ref
     return l;
}
  
inline ostream & operator << ( ostream & out, const MyString & str )
{
     str.print(out);
     return out; 
}

inline istream & operator >> ( istream & in, MyString & str ) 
{
     str.read(in);
     return in; 
}

void testLength() 
{
     MyString t("butter");
     MyString r("fly");
     t+=r;
     MyString x("");
     MyString y("1");
     MyString z = x+y;
     
     cout << "Test Length:" << endl;
     cout << t.length() << " should be 9." << endl;
     cout << x.length() << " should be 0." << endl; 
     cout << y.length() << " should be 1." << endl;
     cout << z.length() << " should be 1." << endl;
     cout << endl;
}


void testindexOf()
{
     MyString a("");
     MyString d("y");
     MyString t("racecar");
     
     cout << "Test IndexOf(char):" << endl;
     cout << a.indexOf('c') << " should be -1." << endl;
     cout << d.indexOf('y') << " should be 0." << endl;
     cout << t.indexOf('c') << " should be 2." << endl;
     cout << endl;
}

void testequal()
{
     MyString t("bananas");
     MyString r("bats");
     t=r;
     MyString x("ban");
     MyString y("anas");
     x=y;
     MyString a("");
     MyString b("");
     a=b;
     MyString c("");
     MyString d("y");
     c=d;
     MyString e("y");
     MyString f("\0");
     e=f;
     cout << "Test =:" << endl;
     cout << t.length() << " should be 4 and " << t << " " << r << " both should be bats" << endl;
     cout << x.length() << " should be 4 and " << x << " " << y << " both should be anas" << endl;
     cout << a.length() << " should be 0 and ." << a << ".   ." << b << ". both should be nothing between periods" << endl;
     cout << c.length() << " should be 1 and " << d << " " << d << " both should be y" << endl;
     cout << e.length() << " should be 0 and ." << e << ".   ." << f << ". both should be nothing between periods" << endl;
     cout << endl;
}

void testdoubleequal()
{
     MyString t("bananas");
     MyString r("bananas");
     MyString x("ban");
     MyString y("anas");
     MyString a("");
     MyString n(" ");
     MyString m(" ");
     MyString d("y");
     MyString e("y");
     MyString s("\0");
     
     cout << "Test ==:" << endl;
     cout << (t==r) << " true" << endl;
     cout << (x==y) << " false" << endl;
     cout << (d==e) << " true" << endl;
     cout << (a==n) << " false" << endl;
     cout << (m==n) << " true" << endl;
     cout << (a==s) << " true" << endl;
     cout << endl;
}

void testindex()
{
     MyString t("bananas");
     MyString a("");
     
     try
     {
          cout << "Test []:" << endl;
          cout << t[2] << " should be n" << endl;
          cout << t[0] << " should be b" << endl;
          cout << t[t.length()-1] << " should be s" << endl;
          //cout << a[0] << " should throw an error" << endl; // should throw an error
     }
     catch (int i)
     {
          cout << "should throw an error" << endl;
          cout << "Got an exception: " << i << endl; 
     }
     
     cout << endl;
}

void testindexOfStrings()
{
     MyString t("bananas");
     MyString w("an"); 
     MyString y("s");
     MyString x("");
     MyString n("na");
     MyString m("anas");
     MyString v("ns");
     MyString a("fdsjkfdlksfjdkl");
     
     cout << "Test IndexOf(Strings):" << endl;
     cout << t.indexOf(w) << " should be 1." << endl;
     cout << t.indexOf(y) << " should be 6." << endl;
     cout << t.indexOf(n) << " should be 2." << endl;
     cout << t.indexOf(m) << " should be 3." << endl;
     cout << t.indexOf(x) << " should be 0." << endl;
     cout << t.indexOf(a) << " should be -1." << endl;
     cout << endl;
}

void testplus()
{
     MyString t("butter");
     MyString r("fly");
     MyString x("ban");
     MyString y("anas");
     MyString a("");
     MyString n(" ");
     MyString M("Hello ");
     MyString m(" World");
     MyString d("y");
     MyString D(" y");
     MyString e("y");
     MyString f("\0");
     
     cout << "Test +:" << endl;
     cout << (t+r) << " should be butterfly" << endl;
     cout << (x+y) << " should be bananas" << endl;
     cout << " ." << (a+f) << ". " << "should be nothing between periods." << endl;
     cout << (a+d) << " should be y" << endl;
     cout << (d+n) << " should be y with space after y" << endl;
     cout << (d+D) << " should be y y" << endl;
     cout << (M + m) << " should be Hello  World" << endl;
     cout << " ." << (a+n) << ". " << "should have a space between periods." << endl;
     cout << " ." << (n+a) << ". " << "should have a space between periods." << endl;
     cout << endl;
}

void testplusequal()
{
 MyString t("sky");
 MyString r("scraper");
 t+=r;
 MyString x("butter");
 MyString y("fly");
 x+=y;
 MyString a("");
 MyString n(" ");
 a+=n;
 MyString e("y");
 e+=a;
 MyString f("\0");
 y+=f;
 
 cout << "Test +=:" << endl;
 cout << (t) << " should be skyscraper" << endl;
 cout << (x) << " should be butterfly" << endl;
 cout << " ." << (a) << ". " << "should have a space between periods." << endl;
 cout << (e) << " should be y  with a space after y." << endl;
 cout << (y) << " should be fly without a space after y." << endl;
 cout << endl;
}

void testReverse() 
{
 ifstream in("input.txt"); // input has 6 test cases
 MyString l;
 cout << "\nTest reverse:" << endl;
 while ( in >> l ) 
 {
  cout << copyConstructorTest(l) << " " << l.length() << " " << l.reverse() << endl;
 }
 cout << endl;
}

int main() 
{
     cout << endl;
     try 
     {          
	  testLength();
          testindexOf();
          testequal();
          testdoubleequal();
          testindex();
          testindexOfStrings();
          testplus();
          testplusequal();
          testReverse();
     }
     catch (int i) 
     {
     cout << "Got an exception: " << i << endl; 
     }
    
     return 0;
}
