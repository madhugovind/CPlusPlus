#include <iostream>
#include <string>
#include <fstream>
#include "Timer.h"
#include <math.h>

using namespace std;

void error(const char *s)
{
       cerr << "Error: " << s << endl;
       throw 0; 
}

struct Hasher 
{
       public:
	virtual int hash(string s, int N) = 0;
};

struct GeneralStringHasher : Hasher
{
	// hash is O(1) because key size is miniscule compared to word list length
	// which is what N represents so because it does not depend
	// on word lsit length it is in constatnt time and therefore O(1)
       virtual int hash(string key, int N)
       {
           unsigned hashVal = 0;
           for (int i = 0; i < key.size(); ++i)
                hashVal = (127 * hashVal + key[i]) % 16908799;
           return hashVal % N;
       }
};

struct ShiftHasher : Hasher
{
	// hash is O(1) because key size is miniscule compared to word list length
	// which is what N represents so because it does not depend
	// on word lsit length it is in constatnt time and therefore O(1)
       virtual int hash(string key, int N)
       {
              const unsigned shift = 6;
              const unsigned zero = 0;
              unsigned mask = ~zero >> (32-shift);  // low 6 bits on
              unsigned result = 0;
              for (int i = 0; i < key.size(); ++i)
                     result = (result << shift) | (key[i] & mask);
              return result % N;
       }
};

struct SumHasher : Hasher 
{
	// hash is O(1) because key size is miniscule compared to word list length
	// which is what N represents so because it does not depend
	// on word lsit length it is in constatnt time and therefore O(1)
	virtual int hash(string s, int N) 
	{
		int result = 0;
		for (int i=0; i<s.size(); ++i)
			result += s[i];
		return abs(result) % N;
	}
};

struct ProdHasher : Hasher 
{
	// hash is O(1) because key size is miniscule compared to word list length
	// which is what N represents so because it does not depend
	// on word lsit length it is in constatnt time and therefore O(1)
	virtual int hash(string s, int N) 
	{
		int result = 1;
		for (int i=0; i<s.size(); ++i)
			result *= s[i];
		return abs(result) % N;
	}
};

class ListNode
{
       public:
       string key;
       int info;
       ListNode * next;
       ListNode(string k, int cap, ListNode * n): key(k), info(cap), next(n){}
       int operator ++ (int num)
       {
              return info++;
       }
	
	// O(1) because insert uses find, which is O(1) and inserts backwards, 
	// which does not depend on the length of the word list
	// makeing it constant time
       static ListNode * insert(string k, int numOccurances, ListNode * l)
       {
              if (!find(k, l))
                     return new ListNode(k, numOccurances, l);
              ++(l->info);
              return l;
                     
       }

	// O(1) because find traverses a linedlist that should be no more than 10% as 
	// long as N and any worst case that does not reach even close to N is O(1)
	// hashing results in constant time helper functions
       static ListNode * find(string k, ListNode * l)
       {
              if (!l)
                     return nullptr;
              else if (l->key == k)
                     return l;
              return find(k, l->next);
       }

       // O(1) because find traverses a linedlist that should be no more than 10% as 
	// long as N and any worst case that does not reach even close to N is O(1)
	// hashing results in constant time helper functions
       static ListNode * findR(string k, ListNode * l)
       {
              if (!l->next)
                     return nullptr;
              else if (l->next->key == k)
                     return l;
              return findR(k, l->next);
	}

       // O(1) because findR is used, which is O(1) and everything else 
	// is single operations with coniditonal that happens once
	// hashing results in constant time helper functions
       static ListNode * remove(string k, ListNode * l)
       {
              if (l)
              {
          	       if (l->key == k)
                 	{
                 	       if (l->info>1)
                 	              (l->info)--;
                 	       else
                 	       {
                        		ListNode * temp = l;
                        		l = l->next;
                        		delete temp;
                 	       }
                 	}
                 	else
                 	{
                 	       ListNode *p = ListNode::findR(k, l);
                 	       if (l->next->info>1)
                 	              (l->next->info)--;
                 	       else
                 	       {
              		       		ListNode *t = p-> next;
              		       		p->next = p->next->next;
              		       		delete t;
                 	       }
                 	}
              }
              else
          	       error("Could not remove word.");
          	return l;
       }
	
       static void deleteList(ListNode * l)
       {
              if(l)
              {
                     deleteList(l->next);
                     delete l;
              }
       }
       
};

class ChainedHashTable 
{
       public:
       Hasher * hashr;
       int hash(string value, int N); // as given above
       ListNode * * T; // T is an array of linked lists
       int capacity;
       int *lengths;

public:
       explicit ChainedHashTable(int cap, Hasher & hasher)
       {
              hashr= &hasher;
              capacity = cap;
              T = new ListNode * [capacity];
              lengths = new int [capacity];
              for (int i =0; i < capacity; ++i)
              {
                     T[i] = nullptr;
                     lengths[i] = 0;
              }
       }
       
       ChainedHashTable(const ChainedHashTable & C)
       {
              hashr = C.hashr;
              capacity = C.capacity;
              T = new ListNode * [capacity];
              for (int i =0; i < capacity; ++i)
              {
                     lengths[i] = C.lengths[i];
                     for (ListNode * p = C.T[i],* n = T[i]; p!=nullptr; p=p->next, n=n->next)
                     {
                            n = new ListNode(p->key, p->info, nullptr);
                     }
              }
       }
       
	// O(1) becase hash and find, which are used, is also O(1)
	// everything else is single operations which are in constant time
	// as nothing depends on word list length
       ListNode & operator [] (string key)
       {
              int h = hashr->hash(key, capacity);
              ListNode * l = ListNode::find(key, T[h]);
              if (!l)
                     error(("Trying to Access Undefined Key: "+key).c_str());
              return *l;
       }
       
       void print()
       {
              ofstream out ("output.txt");
              for (int i = 0; i<capacity; ++i)
              {
                     for (ListNode * p = T[i]; p!=nullptr; p=p->next)
                            out  << p->key << p->info << " ";
                     out << endl;
              }
       }
       
       int minLength()
       {
              int min=lengths[0];
              for (int i = 0; i < capacity; ++i)
                     if(lengths[i]<min)
                            min = lengths[i];
              return min;
       }
       
       int maxLength()
       {
              int max=lengths[0];
              for (int i = 0; i < capacity; ++i)
                     if(lengths[i]>max)
                            max = lengths[i];
              return max; 
       }
       
       int sum()
       {
              int sum=0;
              for (int i = 0; i < capacity; ++i)
                     sum+=lengths[i];
              return sum;
       }
       
       double avg()
       {
              if (capacity<=0)
                     error("Cannot calculate average of empty list");
              return sum()/(double)capacity;
       }
       
       double stddev()
       {
              double varsum=0.0, var=0.0, avge = 0.0;
              avge = avg();
              for (int i = 0; i < capacity; ++i)
                     varsum += (lengths[i] - avge)*(lengths[i] - avge);
              var = varsum / capacity;
              return sqrt(var);
       }
       
       void printLengths()
       {
              for (int i = 0; i < capacity; ++i)
              {
                     cout << i << " " << lengths[i] << endl;
              }
       }
       
	// O(1) because insert and hash is used, which are O(1) for both
	// everything else is single operations that don't depend on anything
	// hashing results in constant time helper functions
       void insert(string key, int info)
       {
              int h = hashr->hash(key, capacity);
              T[h] = ListNode::insert(key, info, T[h]);
              ++lengths[h];
       }
       
	// O(1) because find and hash is used, which are O(1) for both
	// everything else is single operations that don't depend on anything
	// hashing results in constant time helper functions
       int find(string key)
       {
              int h = hashr->hash(key, capacity);
              ListNode * L = ListNode::find(key, T[h]);
              if (!L)
                     error(("Undefined Key: "+key).c_str());
              return L->info;
       }
	
  	// O(1) because remove and hash is used, which are O(1) for both
	// everything else is single operations that don't depend on anything
	// hahing results in constant time helper functions
       void remove(string key)
       {
              int h = hashr->hash(key, capacity);
              T[h] = ListNode :: remove(key, T[h]); 
       }
      	
       ~ChainedHashTable()
       {
              delete [] lengths;
              for (int i = 0; i < capacity; ++i)
                     ListNode::deleteList(T[i]);
              delete [] T;
       }
};

// O(N) because for loop loops through entire list to enter all words
// and insert is O(1) so N*1 = N
void insertAllWords(ifstream & myfile, ChainedHashTable & T, int NWords)
{
	string word;
	if (myfile.is_open())
	{
		for (int i = 0; i < NWords; ++i)
		{
		       getline (myfile,word);
			T.insert(word, 1);
		}
	}
	else
	       error("Cannot open file.");
}

// O(N) because for loop loops through entire list to find each word
// and find is O(1) so N*1 = N
void findAllWords(ifstream & myfile, ChainedHashTable & T, int NWords)
{
       	string word;
	if (myfile.is_open())
	{
		for (int i = 0; i < NWords; ++i)
		{
		       getline (myfile,word);
			if(!T.find(word))
			       error(("Undefined Key: "+word).c_str());
		}
	}
	else
	       error("Cannot open file.");
}

/// O(N) because for loop loops through entire list to remove each word
// and remove is O(1) so N*1 = N/ O(N) 
void removeAllWords(ifstream & myfile, ChainedHashTable & T, int NWords)
{
	// Output file after end of running program should print 
       // each line as a linkedlist stream because print is done after insert and find only.
       // Uncomment print in remove to see it work.

	string word;
	if (myfile.is_open())
	{
		for (int i = 0; i < NWords; ++i)
		{
		       getline (myfile,word);
			T.remove(word);
		}
	}
	else
	       error("Cannot open file.");
}

ChainedHashTable & copyConstructorTest(ChainedHashTable & T)
{
       return T;
}

void printStats(const char *inputFileName, ChainedHashTable & T)
{
       Timer t;
	double eTime;
	ifstream myfile (inputFileName);
	t.start();
	insertAllWords(myfile, copyConstructorTest(T), 45392);
	t.elapsedUserTime(eTime);
	T.print();
	
	Timer t2;
	double eTime2;
	ifstream myfile2 (inputFileName);
	t2.start();
	findAllWords(myfile2, T, 45392);
	t2.elapsedUserTime(eTime2);
	myfile2.close();
	T.print();
	
       cout << " chain length statistics:" << endl;
       cout << "\tmin = " << T.minLength() << "; max = " << T.maxLength() << "; average = " << T.avg() << "; std_dev = " << T.stddev() << endl;
	cout << "\tinsertAllWords: "<< eTime << endl;
       cout << "\tfindAllWords: "<< eTime2 << endl;
       
       Timer t3;
	double eTime3;
	ifstream myfile3 (inputFileName);
	t3.start();
	removeAllWords(myfile3, T, 45392);
	t3.elapsedUserTime(eTime3);
	myfile3.close();
	//T.print();
	
	cout << "\tremoveAllWords: "<< eTime3 << endl;
}
void measure(const char * inputFileName, int NWords, Hasher & hasher)
{
       ifstream in(inputFileName);
       ChainedHashTable T = ChainedHashTable(5000, hasher);
       Timer t1, t2, t3;
       double eTime, eTime2, eTime3;
       t1.start(); insertAllWords(in, T, NWords); t1.elapsedUserTime(eTime); in.close();
       cout << "insertAllWords: " << eTime << endl;
       ifstream in2(inputFileName);
       t2.start(); findAllWords(in2, T, NWords); t2.elapsedUserTime(eTime2); in2.close();
       cout << "findAllWords: " << eTime2 << endl;
       ifstream in3(inputFileName);
       t3.start(); removeAllWords(in3, T, NWords); t3.elapsedUserTime(eTime3); in3.close();
       cout << "removeAllWords: " << eTime3 << endl;
}


void testHash(const char *inputFileName, Hasher & hasher)
{ 
       ChainedHashTable T = ChainedHashTable(5000, hasher);
       printStats(inputFileName, T);
}

int main()  
{
       GeneralStringHasher gh;
         
       // For partition data length
       int numW = 45000;
       cout << "\n\nTesting " << "random.txt" << " on " << "GENERALSTRINGHASHER" << endl;
       for (int i=1, k=0; i<=10 && k<numW; ++i, ++k)
       {
              cout << (i*numW/10) << endl;
              measure("random.txt", i * numW/10, gh);
       }
       cout << "\n\nTesting " << "words.txt" << " on " << "GENERALSTRINGHASHER" << endl;
       for (int i=1, k=0; i<=10 && k<numW; ++i, ++k)
       {
              cout << (i*numW/10) << endl;
              measure("words.txt", i * numW/10, gh);
       }
       cout << endl << endl;
       
       SumHasher sh;
       ShiftHasher ssh;
       ProdHasher ph;
       cout << endl << "Testing " << "random.txt" << endl;
       cout << endl << "Hash function " << "PRODUCTHASHER";
       testHash("random.txt", ph);
       cout << endl;
       cout << endl << "Hash function " << "SHIFTHASHER";
       testHash("random.txt", ssh);
       cout << endl;
       cout << endl << "Hash function " << "SUMHASHER";
       testHash("random.txt", sh);
       cout << endl;
       cout << endl << "Hash function " << "GENERALSTRINGHASHER";
       testHash("random.txt", gh);
       cout << endl;
       return 0;
}



