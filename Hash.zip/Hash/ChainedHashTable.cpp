#include <iostream>
#include <string>
#include <fstream>
#include "Timer.h"
#include <math.h>

using namespace std;

void error(const char *s)
{
       cerr << "Error: " << s << endl;
       throw 0; 
}

struct Hasher 
{
       public:
	virtual int hash(string s, int N) = 0;
};

struct GeneralStringHasher : Hasher
{
       int hash(string key, int N)
       {
           unsigned hashVal = 0;
           for (int i = 0; i < key.size(); ++i)
                hashVal = (127 * hashVal + key[i]) % 16908799;
           return hashVal % N;
       }
};

struct ShiftHasher : Hasher
{
       virtual int hash(string key, int N)
       {
              const unsigned shift = 6;
              const unsigned zero = 0;
              unsigned mask = ~zero >> (32-shift);  // low 6 bits on
              unsigned result = 0;
              for (int i = 0; i < key.size(); ++i)
                     result = (result << shift) | (key[i] & mask);
              return result % N;
       }
};

struct SumHasher : Hasher 
{
	virtual int hash(string s, int N) 
	{
		int result = 0;
		for (int i=0; i<s.size(); ++i)
			result += s[i];
		return abs(result) % N;
	}
};

struct ProdHasher : Hasher 
{
	virtual int hash(string s, int N) 
	{
		int result = 1;
		for (int i=0; i<s.size(); ++i)
			result *= s[i];
		return abs(result) % N;
	}
};

class ListNode
{
       public:
       string key;
       int info;
       ListNode * next;
       ListNode(string k, int cap, ListNode * n): key(k), info(cap), next(n){}
       int operator ++ (int num)
       {
              return info++;
       }
       static ListNode * insert(string k, int numOccurances, ListNode * l)
       {
              if (!find(k, l))
                     return new ListNode(k, numOccurances, l);
              ++(l->info);
              return l;
                     
       }
       static ListNode * find(string k, ListNode * l)
       {
              if (!l)
                     return nullptr;
              else if (l->key == k)
                     return l;
              return find(k, l->next);
       }
       
       static ListNode * findR(string k, ListNode * l)
       {
              if (!l->next)
                     return nullptr;
              else if (l->next->key == k)
                     return l;
              return findR(k, l->next);
       }
       
       static ListNode * remove(string k, ListNode * l)
       {
              if (l)
              {
          	       if (l->key == k)
                 	{
                 	       if (l->info>1)
                 	              (l->info)--;
                 	       else
                 	       {
                        		ListNode * temp = l;
                        		l = l->next;
                        		delete temp;
                 	       }
                 	}
                 	else
                 	{
                 	       ListNode *p = ListNode::findR(k, l);
                 	       if (l->next->info>1)
                 	              (l->next->info)--;
                 	       else
                 	       {
              		       ListNode *t = p-> next;
              		       p->next = p->next->next;
              		       delete t;
                 	       }
                 	}
              }
              else
          	       error("Could not remove word.");
          	return l;
       }
       static void deleteList(ListNode * l)
       {
              if(l)
              {
                     deleteList(l->next);
                     delete l;
              }
       }
       
};

class ChainedHashTable 
{
       public:
       Hasher * hashr;
       int hash(string value, int N); // as given above
       ListNode * * T; // T is an array of linked lists
       int capacity;
       int *lengths;

public:
       explicit ChainedHashTable(int cap, Hasher & hasher)
       {
              hashr= &hasher;
              capacity = cap;
              T = new ListNode * [capacity];
              lengths = new int [capacity];
              for (int i =0; i < capacity; ++i)
              {
                     T[i] = nullptr;
                     lengths[i] = 0;
              }
       }
       
       ChainedHashTable(const ChainedHashTable & C)
       {
              hashr = C.hashr;
              capacity = C.capacity;
              T = new ListNode * [capacity];
              for (int i =0; i < capacity; ++i)
              {
                     lengths[i] = C.lengths[i];
                     for (ListNode * p = C.T[i],* n = T[i]; p!=nullptr; p=p->next, n=n->next)
                     {
                            n = new ListNode(p->key, p->info, nullptr);
                     }
              }
       }
       
       ListNode & operator [] (string key)
       {
              int h = hashr->hash(key, capacity);
              ListNode * l = ListNode::find(key, T[h]);
              if (!l)
                     error(("Trying to Access Undefined Key: "+key).c_str());
              return *l;
       }
       
       void print()
       {
              ofstream out ("output.txt");
              for (int i = 0; i<capacity; ++i)
              {
                     for (ListNode * p = T[i]; p!=nullptr; p=p->next)
                            out  << p->key << p->info << " ";
                     out << endl;
              }
       }
       
       int minLength()
       {
              int min=lengths[0];
              for (int i = 0; i < capacity; ++i)
                     if(lengths[i]<min)
                            min = lengths[i];
              return min;
       }
       
       int maxLength()
       {
              int max=lengths[0];
              for (int i = 0; i < capacity; ++i)
                     if(lengths[i]>max)
                            max = lengths[i];
              return max; 
       }
       
       int sum()
       {
              int sum=0;
              for (int i = 0; i < capacity; ++i)
                     sum+=lengths[i];
              return sum;
       }
       
       double avg()
       {
              if (capacity<=0)
                     error("Cannot calculate average of empty list");
              return sum()/(double)capacity;
       }
       
       double stddev()
       {
              double varsum = 0.0, var=0.0, avge = 0.0;
              avge = avg();
              for (int i = 0; i < capacity; ++i)
                     varsum += (lengths[i] - avge)*(lengths[i] - avge);
              var = varsum / capacity;
              return sqrt(fabs(var));
	}
       
       void printLengths()
       {
              for (int i = 0; i < capacity; ++i)
              {
                     cout << i << " " << lengths[i] << endl;
              }
       }
       
       void insert(string key, int info)
       {
              int h = hashr->hash(key, capacity);
              T[h] = ListNode::insert(key, info, T[h]);
              ++lengths[h];
       }
       
       int find(string key)
       {
              int h = hashr->hash(key, capacity);
              ListNode * L = ListNode::find(key, T[h]);
              if (!L)
                     error(("Undefined Key: "+key).c_str());
              return L->info;
       }
       
       void remove(string key)
       {
              int h = hashr->hash(key, capacity);
              T[h] = ListNode :: remove(key, T[h]); 
       }
       
       ~ChainedHashTable()
       {
              delete [] lengths;
              for (int i = 0; i < capacity; ++i)
                     ListNode::deleteList(T[i]);
              delete [] T;
       }
};

void insertAllWords(const char * file, ChainedHashTable & T)
{
	ifstream myfile (file);
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
		{
			T.insert(word, 1);
		}
		myfile.close();
	}
	else
	       error("Cannot open file.");
}

void findAllWords(const char * file, ChainedHashTable & T)
{
       // Output file after end of running program should print 
       // each line as a linkedlist stream because print is done after insert and find only.
       // Uncomment print in remove to see it work.
       ifstream myfile (file);
	string word;
	if (myfile.is_open())
	{
	       // For partition data time
	       /*for (int k = 0; k< 10; k++)
	       {
	              int i = 0;
	              Timer t;
                     double eTime;
                     t.start();

       		while ( getline (myfile,word) && i < T.capacity/10)
       		{
       			T.insert(word, 1);
       			++i;
       		}
       		
       		t.elapsedUserTime(eTime);
                     cout << k << "th partition time: " << eTime << endl;
	       }*/
		while ( getline (myfile,word) )
		{
			if(!T.find(word))
			       error(("Undefined Key: "+word).c_str());
		}
		myfile.close();
	}
	else
	       error("Cannot open file.");
}

void removeAllWords(const char * file, ChainedHashTable & T)
{
	ifstream myfile (file);
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
		{
			T.remove(word);
		}
		myfile.close();
	}
	else
	       error("Cannot open file.");
}

ChainedHashTable & copyConstructorTest(ChainedHashTable & T)
{
       return T;
}

void printStats(const char *inputFileName, ChainedHashTable & T)
{
       Timer t;
	double eTime;
	t.start();
	insertAllWords(inputFileName, copyConstructorTest(T));
	t.elapsedUserTime(eTime);
	T.print();
	
	Timer t2;
	double eTime2;
	t2.start();
	findAllWords(inputFileName, T);
	t2.elapsedUserTime(eTime2);
	T.print();
	
       cout << " chain length statistics:" << endl;
      cout << "\tmin = " << T.minLength() << "; max = " << T.maxLength() << "; average = " << T.avg() << "; std_dev = " << T.stddev() << endl;
	cout << "\tinsertAllWords: "<< eTime << endl;
       cout << "\tfindAllWords: "<< eTime2 << endl;
       
       Timer t3;
	double eTime3;
	t3.start();
	removeAllWords(inputFileName, T);
	t3.elapsedUserTime(eTime3);
	//T.print();
	
	cout << "\tremoveAllWords: "<< eTime3 << endl;
}

void testHash(const char *inputFileName, Hasher & hasher)
{ 
       ChainedHashTable T = ChainedHashTable(5000, hasher);
       
       // For partition data length
       /*for (double i = 1; i <=10; ++i)
       {
              cout << T.capacity*(i/10) << " ";
       }*/
       
       printStats(inputFileName, T);
}

int main()  
{
         GeneralStringHasher gh;
         SumHasher sh;
         ShiftHasher ssh;
         ProdHasher ph;
         cout << endl << "Testing " << "random.txt" << endl;
         cout << endl << "Hash function " << "PRODUCTHASHER";
         testHash("random.txt", ph);
         cout << endl;
         return 0;
}






