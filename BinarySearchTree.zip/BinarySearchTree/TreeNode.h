#include <iostream>
#include <fstream>
#include <string>

using namespace std;
template <typename KeyType, typename ElementType>

class TreeNode
{
public:
	KeyType key;
	ElementType info;
	TreeNode * left, * right;
	TreeNode(KeyType k, ElementType nfo, TreeNode *l, TreeNode *r): key(k), info(nfo), left(l), right(r) {}
	TreeNode(const TreeNode &); // copy constructor
	TreeNode & operator = (const TreeNode &); // override
   
	ElementType operator ++ (int num)
	{
        	return ++info;
  	}
   	
	// O(1) because does not depend on size as implemented in constant time with a simple
	// return and initializations	
	static TreeNode * newNode(KeyType k, ElementType nfo, TreeNode * l, TreeNode * r)
   	{
   		return new TreeNode(k,nfo,l,r);
   	}
   
	// O(N) if worst case (words.txt) meaning nearly ascending or nearly 
	// descending keys but in other cases like ours with random.txt	it is on average
	// of O(log N) because search splits list into two with and left and right
	// half that it iterates through spliting each time and number of splits makes
	// it O(log N) and we also consider that newNode is O(1) so logN * 1 is still O(logN)
	// though recursive (and N*1=N)
	static TreeNode * insert(KeyType k, ElementType nfo, TreeNode * root)
   	{
       		if (!root)              
			 return newNode(k, nfo, nullptr, nullptr); 
      		if (root->key == k)
       		{
              		root->info++;
              		return root;
       		}

       		if (k<root->key)
              		root->left = insert(k,nfo,root->left);
       		else if (k>root->key)
              		root->right = insert(k,nfo,root->right);
       		return root;
   	}
   
	// O(N) if worst case (words.txt) meaning nearly ascending or nearly 
	// descending keys but in other cases like ours with random.txt	it is on average
	// of O(log N) because search splits list into two with and left and right
	// half that it iterates through spliting each time and number of splits makes
	// it O(log N) 
	static TreeNode * find(KeyType k, TreeNode * t)
   	{
        	if (!t || t->key == k)
              		return t;
           	if (t->key < k)
              		return find(k,t->right);
           	return find(k,t->left);

  	}
	
	// This is just predecessor of current Node so O(1)
	static TreeNode * findPred(TreeNode* n)
	{
    		TreeNode* t = n;
    		while (t->left)
        		t = t->left;
 		return t;
	}
   
	// O(N) if worst case (words.txt) meaning nearly ascending or nearly 
	// descending keys but in other cases like ours with random.txt	it is on average
	// of O(log N) because search splits list into two with and left and right
	// half that it iterates through spliting each time and number of splits makes
	// it O(log N) and we also consider that findPred is O(1) so logN * 1 is still O(logN)
	// though recursive (and N*1=N)
	static TreeNode * remove(string k , TreeNode * root)
   	{
    		if (!root) 
			return root;
    		if (k < root->key)
        		root->left = remove(k,root->left);
   		else if (k > root->key)
       	 		root->right = remove(k,root->right);
    		else
   		 {
        		if (root->info > 1)
        		{
           			(root->info)--;
           			return root;
        		}

        		if (!root->left)
        		{
            			TreeNode *t = root->right;
            			deleteNode(root);
            			return t;
        		}
        		else if (!root->right)
        		{
            			TreeNode *t = root->left;
            			deleteNode(root);
            			return t;
        		}

        		TreeNode *t = findPred(root->right);
 
        		root->key = t->key;
 
        		root->right = remove(t->key,root->right);
   		}
    		return root;
   	}
   	
	static void print(ostream & out , TreeNode * t)
   	{
      		if ( t ) 
		{
       			out << '[';
        		print(out, t->left);
        		out <<'(' << t->key << ',' << t->info << ')';
        		print(out, t->right);
       			out << ']';
   	 	}
    		else
        		out << "nullptr";

   	}
   
       static void printCount(TreeNode * t)
       {
              if (t) 
              {
                     printCount(t->left);
                     cout << "Length " << t->key << ": " << t->info << " word(s)" << endl;
                     printCount(t->right);
              }      
 	}
   
	static void deleteNode(TreeNode * t)
   	{
      		delete t;
   	}
   
	static void deleteTree(TreeNode * t)
   	{
      		if (t)
      		{
         		deleteTree(t->left);
         		deleteTree(t->right);
         		deleteNode(t);
      		}

   	}
};
