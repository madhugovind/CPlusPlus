#include <iostream>
#include <fstream>
#include <string>
#include "TreeNode.h"
#include "Timer.h"
using namespace std;

void error(const char *s)
{
       cerr << "Error: " << s << endl;
       throw 0; 
}

template <typename KeyType, typename ElementType>
class BinarySearchTree
{
	TreeNode<KeyType, ElementType> * root;
public:
       BinarySearchTree()
       {
              root = nullptr;
       }
       
       // Calls find which is O(log N) which is also O(log N) as explained there and does a few more
       // constant time operations so still O(log N)
       int & operator [] (KeyType key)
       {
              TreeNode<KeyType, ElementType> * t = TreeNode<KeyType, ElementType>::find(key, root);
              if (!t)
                     error("Trying to Access Undefined Key");
              return t->info;
       }
      
       // Calls insert which is O(log N) as explained there therefore this is O(log N) too 
       void insert(KeyType key, ElementType info)
       {
              root = TreeNode<KeyType, ElementType>::insert(key, info, root);
       }
       
       // Calls find twice which is also O(log N) as explained there so (2*log N) is still O(N)
       ElementType find(KeyType key)
       {
              TreeNode<KeyType, ElementType> * t = TreeNode<KeyType, ElementType>::find(key, root);
              if ( !t ) 
              {
                     insert(key, ElementType());
                     t = TreeNode<KeyType, ElementType>::find(key, root);
              }
              return t->info; 
       }
      
       // Calls remove which is O(log N) as explained there so therefore this is O(long N) too
       void remove(KeyType key)
       {
              root = TreeNode<KeyType, ElementType>::remove(key, root);
       }
       
       void print(ostream & out)
       {
              TreeNode<KeyType, ElementType>::print(out, root);
       }
       
       void printCount()
       {
              TreeNode<KeyType, ElementType>::printCount(root);
       }
       
       ~BinarySearchTree()
       {
              TreeNode<KeyType, ElementType>::deleteTree(root);
       }
};  

int countAllWords(const char * filename)
{
       ifstream myfile(filename);
       BinarySearchTree<int, int> bst;
       int length = 0;
       string word;
       while (getline(myfile, word))
       {
              length = word.length();
              if (bst.find(length))
                     bst[length]++;
              else
                     bst.insert(length, 1);
       }
       bst.printCount();
}

void insertAllWords(ifstream & myfile, BinarySearchTree<string, int> & B, int NWords)
{
	string word;
	if (myfile.is_open())
	{
		for (int i = 0; i < NWords; ++i)
		{
		       getline (myfile,word);
			B.insert(word, 1);
		}
	}
	else
	       error("Cannot open file.");
}

void findAllWords(ifstream & myfile, BinarySearchTree<string, int> & B, int NWords)
{
	// Output file after end of running program should print 
	// each line as a linkedlist stream because print is done after insert and find only.
	// Uncomment print in remove to see it work.
	string word;
	if (myfile.is_open())
	{
	       for (int i = 0; i < NWords; ++i)
		{
		       getline (myfile,word);
			if(!B.find(word))
			       error(("Undefined Key: "+word).c_str());
		}
	}
	else
	       error("Cannot open file.");
}

void removeAllWords(ifstream & myfile, BinarySearchTree<string, int> & B, int NWords)
{
	 // uncomment print in printstats to see remove work on output file
	string word;
	if (myfile.is_open())
	{
		for (int i = 0; i < NWords; ++i)
		{
		       getline (myfile,word);
			B.remove(word);
		}
	}
	else
	       error("Cannot open file.");
}


void printStats(const char *inputFileName, BinarySearchTree<string, int> & B)
{
       	ofstream out ("output.txt");

       	Timer t;
	double eTime;
	ifstream myfile (inputFileName);
	t.start();
	insertAllWords(myfile, B, 45392);
	t.elapsedUserTime(eTime);
	B.print(out);
	
	cout << "\tinsertAllWords: "<< eTime << endl;
	
	Timer t2;
	double eTime2;
	ifstream myfile2 (inputFileName);
	t2.start();
	findAllWords(myfile2, B, 45392);
	t2.elapsedUserTime(eTime2);
	myfile2.close();
	B.print(out);
	
       cout << "\tfindAllWords: "<< eTime2 << endl;
       
       	Timer t3;
	double eTime3;
	ifstream myfile3 (inputFileName);
	t3.start();
	removeAllWords(myfile3, B, 45392);
	t3.elapsedUserTime(eTime3);
	myfile3.close();
	//B.print(out);
	
	cout << "\tremoveAllWords: "<< eTime3 << endl;
}
void measure(const char * inputFileName, int NWords)
{
       BinarySearchTree<string, int> B;
       ofstream out ("output.txt");
       Timer t1, t2, t3;
       double eTime, eTime2, eTime3;
       
       ifstream in(inputFileName);
       t1.start(); insertAllWords(in, B, NWords); t1.elapsedUserTime(eTime); in.close();
       cout << "insertAllWords: " << eTime << endl;
       B.print(out);
       
       ifstream in2(inputFileName);
       t2.start(); findAllWords(in2, B, NWords); t2.elapsedUserTime(eTime2); in2.close();
       cout << "findAllWords: " << eTime2 << endl;
       B.print(out);
       
       ifstream in3(inputFileName);
       t3.start(); removeAllWords(in3, B, NWords); t3.elapsedUserTime(eTime3); in3.close();
       cout << "removeAllWords: " << eTime3 << endl;
       //B.print(out);
}


void testBST(const char *inputFileName)
{ 
       BinarySearchTree<string, int> B;
       printStats(inputFileName, B);
}

int main()  
{
         
       // For partition data length
       int numW = 45500;
       cout << "\n\nTesting " << "random.txt" << endl;
       for (int i=1, k=0; i<=10 && k<numW; ++i, ++k)
       {
              cout << "Partition " << i << endl;
              measure("random.txt", i * numW/10);
       }
       
       cout << endl << "Testing " << "random.txt" << endl;
       testBST("random.txt");
       
       cout << endl << endl;
       countAllWords("random.txt");
       
       // uncomment to test words
       /*cout << "\n\nTesting " << "words.txt" << endl;
       for (int i=1, k=0; i<=10 && k<numW; ++i, ++k)
       {
              cout << "Partition " << i << endl;
              measure("words.txt", i * numW/10);
       }
       cout << endl;
       //cout << endl << "Testing " << "words.txt" << endl;
       //testBST("words.txt");*/
       
       cout << endl;
       return 0;
}
