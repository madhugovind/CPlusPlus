#include <iostream>
#include <string>
#include <fstream>
#include "Timer.h"

using namespace std;

void error(const char *s)
{
       cerr << "Error: " << s << endl;
       throw 0; 
}

class Sorter
{
       public:
       int cap;
       int size;
       string * buf;
       
	virtual void sort() = 0;
	
	Sorter(int max): cap(max), size(0), buf(new string[max]) {}
	Sorter(const Sorter &); // copy constructor
       	Sorter & operator = (const Sorter &); // override
	
	// Worst case because it calls sort() should be O(N^3) as the sort's worst
	// case for all Sorter instances is O(N^2) but specifically on average
	// O(N^3) for InsertionSorter
	// O(N^2logN) for QuickSorter
	// O(N^2logN) for HeapSorter
	// or O(N) without the sort for any Sorter instance because it traverses
	// through to insert each element in the file
	void insertAllFromFile(int numItemsToLoad, const char * fileName)
	{
	       	ifstream myfile(fileName);
		string word;
       		if (myfile.is_open())
       		{
       	       		Timer t;
       	       		double eTime;
       	       		t.start();
       			for (int i = 0; i < numItemsToLoad; ++i)
       			{
       		       		if (getline (myfile,word))
       		       		{
       			       		buf[i] = word;
       			       		++size;
       		       		}
       				else
       			       		break;
       			}
       			sort();
       			t.elapsedUserTime(eTime);
       			cout << eTime << endl;
       		}
       		else
       	       		error("Cannot open file.");
       		myfile.close();
	}

       void print(ostream & out)
       {
              out << buf[0];
              for (int i = 1; i < size; ++i)
              {
                     out << endl << buf[i];
              }
       }
	
	virtual ~Sorter(){}
	
};

class InsertionSorter : public Sorter
{
       public:
       InsertionSorter(int cap):Sorter(cap){}
      
       // O(N^2) because two for-loops worst case traverse through whole 
       // list twice to first choose element to sort and possibly place at
       // end if right place
       static void insertionsort(string * a, int low, int size)
       {
              string key;
              for (int i = low+1; i < size; i++)
              {
                     key = a[i];
                     int pos = i;
 
                     while (pos > 0 && a[pos-1] > key)
                     {
                         a[pos] = a[pos-1];
                         --pos;
                     }
                     a[pos] = key;
              }
       }
       
	// O(N^2) because it calls insertionsort
	virtual void sort() 
	{
	       insertionsort(buf, 0, size);
	}
	
	~InsertionSorter()
	{
	       delete [] buf;
	}
};


class QuickSorter : public Sorter
{
       public:
       QuickSorter(int cap):Sorter(cap){}
       
       static void swap(string * i, string * j)
       {
              string t = *i;
              *i = *j;
              *j = t;
       }
       
       static int partition(string * a, int low, int high, string p)
       {
              string pivot = p;
              int i = low,  j = high - 1;
              for (;;)
              {
                     while ( a[++i ] < pivot ) { }
                     while ( pivot < a[--j] ) { }
                     if ( i < j ) swap( &a[i], &a[j] );
                     else break;
              }
              return i;

       }
       
       static string medianOfThree(string * a, int low, int high)
       {
              int mid = (low+high)/2;
              if ( a[mid] < a[low] ) swap( &a[low], &a[mid] );
              if ( a[high] < a[low] ) swap( &a[low], &a[high] );
              if ( a[high] < a[mid] ) swap( &a[mid], &a[high] );
              swap( &a[mid], &a[high-1] );
              return a[high-1];
       }
       
       // O(NlogN) average although O(N^2) worst case
       static void quicksort(string * a, int low, int high)
       {
              if (high - low < 100)
                     InsertionSorter::insertionsort(a, low, high+1);
              else
              {
                     string pivot = medianOfThree(a, low, high);
                     int i = partition(a, low, high, pivot);
                     quicksort(a, low, i-1);
                     quicksort(a, i+1, high);
              }
       }
	
       // O(NlogN) because quicksort called
       virtual void sort()
       {
              quicksort(buf, 0, size-1);

       }
       
       ~QuickSorter()
	{
	       delete [] buf;
	}
};

class HeapSorter : public Sorter
{
       public:
       HeapSorter(int cap):Sorter(cap){}
       
       static int leftChild(int cur)
       {
              return 2*cur+1;
       }
       
       static void siftDown(string * a, int cur, int N)
       {
              int child;
              string cur_str = a[cur];
              for (; leftChild(cur)<N; cur=child)
              {
                     child = leftChild(cur);
                     if (child != N-1 && a[child] < a[child+1])
                            ++child;
                     if(cur_str < a[child])
                            a[cur]=a[child];
                     else
                            break;
              }
              a[cur] = cur_str;
       }
       
       // O(NlogN) average although worst case is O(N^2) 
       virtual void sort()
       {
              //Heapify();
              for (int start = size/2; start >=0; --start)
                     siftDown(buf, start, size);
              for (int end = size-1; end>0; --end)
              {
                     QuickSorter::swap(&buf[0], &buf[end]);
                     siftDown(buf, 0, end);
              }
       
       }
       
       ~HeapSorter()
	{
	       delete [] buf;
	}
};

void measureAll(const char *fileName)
{
       cout << endl;
       for (int i=1; i<=10; ++i)
       {
              InsertionSorter T1(45500); 
              QuickSorter T2(45500);  
              HeapSorter T3(45500);

              cout << "Partition " << i << " Time for InsertionSorter: ";
              T1.insertAllFromFile(i*T1.cap/10, fileName);
              ofstream out("insertSort.txt");
              T1.print(out);
              cout << "Partition " << i << " Time for QuickSorter: ";
              T2.insertAllFromFile(i*T2.cap/10, fileName);
              ofstream out2("quickSort.txt");
              T2.print(out2);
              cout << "Partition " << i << " Time for HeapSorter: ";
              T3.insertAllFromFile(i*T3.cap/10, fileName);
              ofstream out3("heapSort.txt");
              T3.print(out3);
       }
       cout << endl;
}


int main()
{
       cout << endl;
       cout << "Testing random.txt" << endl;
       measureAll("random.txt");
       cout << "Testing words.txt" << endl;
       measureAll("words.txt");
       cout << endl;
       return 0;
}
