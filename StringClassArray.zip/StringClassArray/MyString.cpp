#include <iostream>
#include <fstream>

using namespace std;

int NumAllocations = 0;


class MyString
{
 char * buf;
 
 void error(const char *s)
 {
  cerr << "Error: " << s << endl;
  throw 1; 
 }
 
 // T(N) = 3
 static char * new_char_array(const int & len)
 {
 	NumAllocations++;
 	return new char[len];
 }

 static void delete_char_array(char * c)
 {
 	NumAllocations--;
 	delete[] c;
 }


// T(N) = 1+1+1+1+3N = 3N+4
 int strlen(const char * s = "") const
 {
  if (s == nullptr)
   return 0;
  int i = 0; 
  while (s[i] != '\0')
   i++;
  return i;
 }
  
  // T(N) = 1+1+1+1+(3N+4)+6N = 9N + 8
 char * strcpy(char *destination, const char *source) const
 {
  for (int i = 0; source[i]!='\0'; i++)
   destination[i] = source[i];
  destination[strlen(source)] = '\0';
  return destination;
 }
  
  // T(N) = 1+1+3+3N+4+1+(9N+8)+2 = 12N + 20
 char * strdup(const char * s = "")
 {
  if (s != nullptr) 
   {
     buf = new_char_array(strlen(s)+1);
     if (buf != nullptr)
     {
      return strcpy(buf, s);
     }
   }
   else
    buf = nullptr;
   return nullptr;
 }

 char * strcat(char *a, const char *b) const
 {
   char *s = a + strlen(a);
   strcpy(s, b);
  
   return a;
 }
  
 char * str2dup(char * d , const char * s = "") const
 {
   strcpy(d, buf); 
   strcat(d, s); 
 }

 char * strrev(char *dest, char *src) const
 {
  if (src != nullptr) 
   {
     if (dest != nullptr)
     {
      for (int i =0; i < length(); i++)
       dest[i] = src[length()-1-i];
      dest[strlen(src)] = '\0';
      return dest;
     }
       
   }
   return nullptr;
 }
 
 // T(N) = 1+1+3N+5+1+3N+4+1+11N+1 = 17N+14
 int strcmp ( const char * str1, const char * str2 ) const
 {
  int len = length(); // 1+1+3N+5
  if (len != strlen(str2)) // 1+3N+4
  {
   return 0; // 1
  }
   
  for (int i = 0; i < len -1; i++) // 1+N(11)
  {
   if (str1[i] > str2[i] || str1[i] < str2[i])
   {
    return 0;
   }
  }
  return 1; // 1
 }


// T(N) = 1+3N+5+3N+6+ 16N^2 + 2N+3+1 = 16N^2 + 8N + 16
 char * strstr (const char * buf2, const char * pat2) const
 {
  
  int match = -1; // 1
  int lenpat2 = strlen(pat2); // 3N+5
  int len = length(); // 3N+6
  
  // 1+ N((16N+1)+1) = 1+ 16N^2 + 2N+2 = 16N^2 + 2N+3
  for (int i = 0; i < len; i++) //1
  {
  // 16N+1
   for (int j = 0; j < lenpat2; j++)
   {
    if (i+j > len) // 1+1
    {
     return nullptr; // 1
    }
    if (buf2[i+j] != pat2[j] ) // 4
    {
     match = -1; // 1
     break; // 1
    }
    match = i; // 1
   }
   if (match != -1) // 1
   {
    return (char *)(buf2+match); // 1+1+1
   }
   match = -1; // 1
  }
  
  return nullptr; // 1
 }
 
 public:
  explicit MyString( const char * s = "")
  {
    strdup( s);
  }
  
  
  MyString( const MyString & s )
  {
    buf = strdup( s.buf);
  }
  
  
  MyString & operator = ( const MyString & s )
  {
   delete_char_array(buf);
   strdup( s.buf);
   return *this;
  }
  
  
  char & operator [] ( const int index )
  {
   if(index >= length() || index < 0 || buf == nullptr)
    error("Index out of bounds**");
    
    return buf[index];
  }
  
  // T(N) = 3N + 4+1 = 3N+5
  int length() const 
  {
    return strlen(buf);
  }
     
  
  int indexOf( char c ) const
  {
   if (c == '\0')
    return length() +1;
   for (int i = 0; i < length(); i++)
   {
    if (buf[i] == c)
    {
     return i;
    }
   }
   return -1;
  }
  
  
  int indexOf( const MyString & pat ) const 
  {
   char * p = strstr(buf, pat.buf);
   if (strlen(pat.buf) == 0)
    return 0;
   if (p == nullptr)
    return -1;
   return p-buf;
  }
  
  
  bool operator == ( const MyString & s ) const
  {
   return strcmp(buf, s.buf);
  }
  
  
  MyString operator + ( const MyString & s ) const
  {
   int len = length() + strlen(s.buf) + 1; 
   char* a = new_char_array(len); 
   str2dup(a, s.buf); 
   MyString news( a ); 
   delete_char_array(a);
   return news;
  }
  
  
  MyString & operator += ( const MyString & s )
  {
   *this = *this + s;
   return *this;
  }
  
  
  MyString reverse() const
  {
   MyString newS(buf);
   strrev(newS.buf, buf);
   return newS;
  }
    
  
  void print( ostream & out ) const
  {
   out << buf;
  }
  
 
  void read( istream & in )
  {
   char * d = new_char_array(100000);
   in.getline(d, 100000);
   delete_char_array(buf);
   buf = d;
  }
  
  
  ~MyString()
  {
   delete_char_array(buf);
  }
};


inline ostream & operator << ( ostream & out, const MyString & str )
{
 str.print(out);
 return out; 
 
}

inline istream & operator >> ( istream & in, MyString & str ) 
{
 str.read(in);
 return in; 
}
 

MyString copyConstructorTest(MyString l) 
{
 // explicitly calling constructor
 // passing by value
 // passing by ref
 return l;
}

void testequal()
{
 MyString t("bananas");
 MyString r("bats");
 t=r;
 MyString x("ban");
 MyString y("anas");
 x=y;
 MyString a("");
 MyString b("");
 a=b;
 MyString c("");
 MyString d("y");
 c=d;
 MyString e("y");
 MyString f("");
 e=f;
 cout << "Test =:" << endl;
 cout << t.length() << " should be 4 and " << t << " " << r << " both should be bats" << endl;
 cout << x.length() << " should be 4 and " << x << " " << y << " both should be anas" << endl;
 cout << a.length() << " should be 0 and ." << a << ".   ." << b << ". both should be nothing between periods" << endl;
 cout << c.length() << " should be 1 and " << c << " " << d << " both should be y" << endl;
 cout << e.length() << " should be 0 and ." << e << ".   ." << f << ". both should be nothing between periods" << endl;
 cout << endl;
}

void testindex()
{
 MyString t("bananas");
 MyString a("");
 
 try
 {
  cout << "Test []:" << endl;
  cout << t[2] << " should be n." << endl;
  cout << t[0] << " should be b." << endl;
  cout << t[t.length()-1] << " should be s." << endl;
  //cout << a[0] << " should throw an error" << endl; // should throw an error
 }
 catch (int i)
 {
  cout << "should throw an error" << endl;
  cout << "Got an exception: " << i << endl; 
 }
 
 cout << endl;
}

void testindexOf()
{
 MyString a("");
 MyString d("y");
 MyString t("racecar");
 
 cout << "Test IndexOf(char):" << endl;
 cout << t.indexOf('\0') << " should be 8." << endl; // because every c-string is null terminated this program considers sentinal as last 'hidden' character
 cout << a.indexOf('c') << " should be -1." << endl;
 cout << d.indexOf('y') << " should be 0." << endl;
 cout << t.indexOf('c') << " should be 2." << endl;
 cout << endl;
}

void testindexOfStrings()
{
 MyString t("bananas");
 MyString w("an"); 
 MyString y("s");
 MyString x("");
 MyString a("\0");
 
 cout << "Test IndexOf(Strings):" << endl;
 cout << t.indexOf(w) << " should be 1." << endl;
 cout << t.indexOf(y) << " should be 6." << endl;
 cout << t.indexOf(x) << " should be 0." << endl;
 cout << t.indexOf(a) << " should be 0." << endl;
 cout << endl;
}

void testdoubleequal()
{
 MyString t("bananas");
 MyString r("bananas");
 MyString x("ban");
 MyString y("anas");
 MyString a("");
 MyString n(" ");
 MyString d("y");
 MyString e("y");
 MyString f("\0");
 
 cout << "Test ==:" << endl;
 cout << (t==r) << endl;
 cout << (x==y) << " false" << endl;
 cout << (d==e) << endl;
 cout << (a==f) << endl;
 cout << (a==n) << " false" << endl;
 cout << endl;
}

void testplus()
{
 MyString t("butter");
 MyString r("fly");
 MyString x("ban");
 MyString y("anas");
 MyString a("");
 MyString n(" ");
 MyString d("y");
 MyString e("y");
 MyString f("\0");
 
 cout << "Test +:" << endl;
 cout << (t+r) << " should be butterfly" << endl;
 cout << (x+y) << " should be bananas" << endl;
 cout << " ." << (a+f) << ". " << "should be nothing between periods" << endl;
 cout << (a+d) << " should be y" << endl;
 cout << (d+n) << " should be y with space after y" << endl;
 cout << " ." << (a+n) << ". " << "should have a space between periods" << endl;
 cout << endl;
}

void testplusequal()
{
 MyString t("sky");
 MyString r("scraper");
 t+=r;
 MyString x("butter");
 MyString y("fly");
 x+=y;
 MyString a("");
 MyString n(" ");
 a+=n;
 MyString e("y");
 e+=a;
 MyString f("\0");
 y+=f;
 
 cout << "Test +=:" << endl;
 cout << (t) << " should be skyscraper" << endl;
 cout << (x) << " should be butterfly" << endl;
 cout << " ." << (a) << ". " << "should have a space between periods" << endl;
 cout << (e) << " should be y  with a space after y" << endl;
 cout << (y) << " should be fly" << endl;
 cout << endl;
}

void testReverse() 
{
 ifstream in("input.txt"); // input has 6 test cases
 MyString l;
 cout << "Test reverse:" << endl;
 while ( in >> l ) 
 {
  cout << copyConstructorTest(l) << " " << l.length() << " " << l.reverse() << endl;
 }
 cout << endl;
}

void testLength() 
{
 MyString t("butter");
 MyString r("fly");
 t+=r;
 MyString x("");
 MyString y("1");
 MyString z = x+y;

 cout << "Test Length:" << endl;
 cout << t.length() << " should be 9." << endl;
 cout << x.length() << " should be 0." << endl;
 cout << z.length() << " should be 1." << endl;
 cout << endl;
 
}

int main() 
{
 cout << endl;
 try 
 {
  testequal();
  testindex();
  testindexOf();
  testindexOfStrings();
  testdoubleequal();
  testplus();
  testplusequal();
  testReverse();
  testLength();
 }
 catch (int i) 
 {
  cout << "Got an exception: " << i << endl; 
 }
 
 cerr << "Net memory allocated at program end: " << NumAllocations << endl; 
 cerr << "(should be zero! positive = memory leak, negative = duplicate delete)\n"; 
 return 0;
}	
