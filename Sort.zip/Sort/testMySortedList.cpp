#include <iostream>
#include <fstream>
#include "Timer.h"

using namespace std;

class SortedLinkedList
{
	
	struct ListNode
	{
	     string info;
	     ListNode * next;
	     ListNode(string s, ListNode * n): info(s), next(n){}
	     
	     	static void error(const char *s)
		{
			cerr << "Error: " << s << endl;
			throw 1; 
		}
	     
	     	static ListNode * deleteAll(ListNode * l)
		{
			ListNode* temp = l;
	          	while( temp != nullptr ) 
	          	{
	               		ListNode* next = temp->next;
	               		delete temp;
	               		temp = next;
	          	}
	          	l = nullptr;
		}
	     
	    	static ListNode* copy( ListNode* current ) // O(N)
	     	{
	       		if (current==nullptr)   
	          	return nullptr;
	          	ListNode * newLN = new ListNode(current->info, nullptr);
	          	ListNode * result = newLN;
	          	for (ListNode * p = current->next; p != nullptr; p = p-> next,newLN = newLN->next)
	          	{
	               		newLN -> next = new ListNode ( p->info, nullptr);
	               		//newLN = newLN->next;
	          	}
	      		return result;
	     	}
	     
	    	static int len(ListNode * l)
	     	{
	        	int len = 0;
	          	for (ListNode * p = l; p != nullptr; p=p->next)
	               		++len;
	          	return len;
	     	}
	};
	
	ListNode * head;

public:
	SortedLinkedList()
	{
		head = nullptr;
	}
	
	SortedLinkedList (const SortedLinkedList & L)
	{
		if (L.head == nullptr)
			head = ListNode::copy(L.head);
	}
	
	SortedLinkedList & operator = (const SortedLinkedList & L)
	{
		ListNode::deleteAll(head);
		head = ListNode::copy(L.head);
	}
	
	bool isEmpty()
	{
		return (head == nullptr);
	}
	
	bool isFull()
	{
		return false;
	}
	
	// O(N) because for loop traverses through till node's position is found which could go to size N
	void insert(string word)
	{
		ListNode * newNode = new ListNode (word, nullptr);
		if (isEmpty() || head->info > newNode->info)
		{
	        	newNode->next = head;
	        	head = newNode;
		}
		else
		{
			ListNode *p, *result;
			for (p = head, result = p; p->next!=nullptr && p->next->info < newNode->info; p=p->next){}
			newNode->next = p->next;
			p->next = newNode;
			head = result;
		}
	}
	
	//O(N) because there is one for loop that traverses the size 0-N
	bool find(string word)
     	{
          	for (ListNode * p = head; p!=nullptr; p=p->next)
               	if (p->info==word)
                	return true;
          	ListNode::error("Cannot find word.");
		return false;
     	}
	
	ListNode * findR(string word)
     	{
          	for (ListNode * p = head; p->next!=nullptr; p=p->next)
               	if (p->next->info==word)
                	return p;
     		return nullptr;
     	}
	
	//O(N) because find is O(N) as explained above
     	void remove (string word)
     	{
          	if (head!=nullptr)
          	{
          		ListNode *p = findR(word);
          		if (head->info == word)
          		{
          			ListNode * temp = head;
          			head = head->next;
          			delete temp;
          		}
          		else
          		{
		          	ListNode *t = p-> next;
		          	p->next = p->next->next;
		          	delete t;
          		}
          	}
          	else
          		ListNode::error("Could not remove word.");
     	}
	
	~SortedLinkedList()
	{
		ListNode::deleteAll(head);
	}
	
	void print()
	{
		ofstream out("SortedLinkedList.txt");
		ListNode * p;
		if (head != nullptr)
		{
			for (p = head; p->next != nullptr; p=p->next)
				out << p->info << endl;
			out << p->info;
		}
		
	}
	
};

class SortedArrayList
{
	string * buf;
	int capacity;
	int size;
	
	static void error(const char *s)
	{
		cerr << "Error: " << s << endl;
		throw 1; 
	}
	
	string * dupList(string * dest, string * src)
	{
		for (int i = 0; i < size; ++i)
			dest[i]=src[i];
		return dest;
	}

	// O(log N) because binary search "splits" buf in half to only check
	// the half that the word is contained in and the number of splits is log N. 
	static int binary_search(string * buf, string word, int min, int max)
	{
		int size = max+1;
		int mid;
		while (max >= min) 
		{
       			mid = (max+min) / 2;
       			if (buf[mid] == word)
       				return mid;
       			else if (buf[mid] > word)
       				max =  mid - 1;
       			else
       				min = mid + 1;
		}

		if (min == size)
       			return size;
		else if(buf[min] > word)
       			return min;
	}

public:
	SortedArrayList(int cap)
		: buf(new string[cap]), capacity(cap), size(0) {}
  
	SortedArrayList( const SortedArrayList & L )
	{
		size = L.size;
		capacity = L.capacity;
		buf = new string[capacity];
		SortedArrayList::dupList(buf, L.buf);
	}
  
	SortedArrayList & operator = ( const SortedArrayList & L )
	{
		delete [] buf;
		capacity = L.capacity;
		size = L.size;
		buf = new string[capacity];
		SortedArrayList::dupList(buf, L.buf);
		return *this;
	}
	
	bool isEmpty() const
	{
		return (size == 0);
	}
	
	bool isFull() const
	{
		return (size == capacity);
	}
	
	//O(N) because buf is traversed through size 0-N
	void copy_down(string * buf, int hole)
	{
		for (int i = size; i > hole; --i)
			buf[i] = buf[i-1];
	}
	
	//O(N) because buf is traversed through size 0-N
	void copy_up(string * buf, int hole)
	{
		if (size > 1)
		{
			for (int i = hole; i < size-1; ++i)
				buf[i] = buf[i+1];
			--size;
		}
		else
			buf[hole] = "";
	}
	
	//Binary Search is O(log N) as explained above and copy Down is O(N) if worst 
	//case as explained above so worst case is O(N) for insert
	void insert(string word)
	{
		int hole = SortedArrayList::binary_search(buf, word,0,size-1);
		if ( buf[hole] != word )
		{
			SortedArrayList::copy_down(buf, hole);
			buf[hole] = word;
			++size;
		}
		else
			error("List is full or duplicate element.");
	}
	
	//find calls Binary Search which is O(log N) for above reasons so that would 
	//be the time complexity for find too
	bool find(string word) const
	{
		if (isEmpty())
		{
			error("Trying to find word in empty list.");
			return false;
		}
		int hole = SortedArrayList::binary_search(buf, word, 0, size-1);
		if (buf[hole] == word)
       			return true;
       		error("Word not found.");
		return false;
	}
	
	//O(N) because copy Up traverses through size 0-N at worst case, which overrides
	//binary_search of O(log N)
	void remove(string word)
	{
		int hole = SortedArrayList::binary_search(buf, word, 0, size-1);
		if (buf[hole]==word)
			SortedArrayList::copy_up(buf, hole);
		else
			error("Cannot be removed.");
	}
	
	~SortedArrayList()
	{
		delete [] buf;
	}
	
	void print()
	{
		ofstream out;
		out.open("SortedArrayList.txt");
		for (int i = 0; i < size-1; ++i)
			out << buf[i] << endl;
		out << buf[size-1];
	}
};

// O(N^2) because worst case for insert is O(N) and a while loop traversing
// size N words is N^2
void insertAllWords(SortedArrayList & L)
{
	ifstream myfile ("random.txt");
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
			L.insert(word);
		myfile.close();
	}
	else
	       cout << "Cannot open file." << endl;
}

// O(N^2) because worst case for find is O(N) and a while loop traversing
// size N words is N^2
void findAllWords(SortedArrayList & L)
{
	ifstream myfile ("random.txt");
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
			L.find(word);
		myfile.close();
	}
	else
	       cout << "Cannot open file." << endl;
}

// O(N^2) because remove is O(N) and a while loop traversing
// size N words is N^2
void removeAllWords(SortedArrayList & L)
{
	ifstream myfile ("random.txt");
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
			L.remove(word);
		myfile.close();
	}
	else
	       cout << "Cannot open file." << endl;
}

void testSortedArrayList() 
{
	SortedArrayList L(45500);
	cout << "\nTest SortedArrayList:" << endl;
	
	Timer t;
	double eTime;
	t.start();
	insertAllWords(L);
	t.elapsedUserTime(eTime);
	cout << "insertAllWords: "<< eTime << endl;
	
	L.print();
	
	Timer t2;
	double eTime2;
	t2.start();
	findAllWords(L);
	t2.elapsedUserTime(eTime2);
	cout << "findAllWords: "<< eTime2 << endl;
	
	L.print();
	
	Timer t3;
	double eTime3;
	t3.start();
	removeAllWords(L);
	t3.elapsedUserTime(eTime3);
	cout << "removeAllWords: "<< eTime3 << endl;
	
	L.print();
}

// O(N^2) because there is a while loop that traverses through the size from 0-N and
// insert has a for loop so N*N=N^2
void insertAllWords(SortedLinkedList & L)
{
	ifstream myfile ("random.txt");
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
			L.insert(word);
		myfile.close();
	}
	else
	       cout << "Cannot open file." << endl;
}

// O(N^2) because there is a while loop that traverses through the size from 0-N and
// find has a for loop so N*N=N^2
void findAllWords(SortedLinkedList & L)
{
	ifstream myfile ("random.txt");
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
			L.find(word);
		myfile.close();
	}
	else
	       cout << "Cannot open file." << endl;
}

// O(N^2) because there is a while loop that traverses through the size from 0-N and
// remove has a for loop so N*N=N^2 
void removeAllWords(SortedLinkedList & L)
{
	ifstream myfile ("random.txt");
	string word;
	if (myfile.is_open())
	{
		while ( getline (myfile,word) )
			L.remove(word);
		myfile.close();
	}
	else
	       cout << "Cannot open file." << endl;
}

void testSortedLinkedList() 
{
	SortedLinkedList L;
	cout << "\nTest SortedLinkedList:" << endl;
	
	Timer t;
	double eTime;
	t.start();
	insertAllWords(L);
	t.elapsedUserTime(eTime);
	cout << "insertAllWords: "<< eTime << endl;
	
	L.print();
	
	Timer t2;
	double eTime2;
	t2.start();
	findAllWords(L);
	t2.elapsedUserTime(eTime2);
	cout << "findAllWords: "<< eTime2 << endl;
	
	L.print();
	
	Timer t3;
	double eTime3;
	t3.start();
	removeAllWords(L);
	t3.elapsedUserTime(eTime3);
	cout << "removeAllWords: "<< eTime3 << endl;

	L.print();
	cout << endl;
}

int main()
{
	cout << endl;
	testSortedArrayList();
	testSortedLinkedList();
	return 0;
}
