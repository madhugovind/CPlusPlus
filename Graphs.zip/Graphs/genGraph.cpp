#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdlib>
#include<ctime>
#include<set>
#include<cmath>

using namespace std;



////////////////////////
// Class Declarations //
////////////////////////


//class to keep track of groupings
class Groups
{
private:
	struct group
	{
		int link;
		int size;
	};

private:
	int N; //number of elements to be grouped
	group* groups; //pointer to an array of groups

public:
	//constructors/destructor
	Groups(int numElements);
	Groups(const Groups& toCopy);
	~Groups();

	//function to find the group number of an element
	int find_group(int i);

	//function to combine two groups together
	void combineGroups(int i, int j);
};


struct Edge
{
public:
	int u, v;  //u,v = incident vertices
	mutable int w;  //w = weight of edge

public:
	//constructor
	Edge(int i, int j, int c);

	//ranks edges based on their connectivity, NOT WEIGHTS!
	friend bool operator<(const Edge& e1, const Edge& e2);
};


//class representing a graph as solely a collection of edges
class Graph
{
private:
	int V; //number of vertices
	int minW; //edge-weight min
	int maxW; //edge-weight max
	set<Edge> edges; //set of edges (side note: STL set is implemented as a balanced binary search tree)
	Groups connectedComponents;  //keeps track of the groups of vertices that are interconnected

public:
	//constructor
	Graph(int N = 0, int w_min = 1, int w_max = 15);

	//functions to add edges to the graph
	bool addEdge(int i, int j, int c);
	bool addEdge(Edge e);
	void addRandomEdges();
	void addRandomWeightEdge(int i, int j);

	//misc public fxns
	void generateRandomConnectedGraph();
	int numEdges();
	void saveGraph(string filename = "graph.txt");
	void printGraph();
};



/////////////////////////////////////////////////////////////////////////////////////////



////////////
// main() //
////////////


int main()
{
	cout << endl;
	//////////////////////////////


	srand(time(0));

	int V = -1;  //V = number of vertices

	cout << " RANDOM GRAPH GENERATOR" << endl << endl;

	cout << " (your graph will be saved as \"graph.txt\")" << endl << endl << endl;

	cout << "     Enter number of vertices:  ";
	cin >> V;  //obtain number of vertices for our graph

			   //repeat until number of vertices entered is between 1-200
	while (V <= 0)
	{
		cout << "     Enter positive number of vertices:  ";
		cin >> V;
	}

	Graph g(V);
	g.generateRandomConnectedGraph();
	g.saveGraph();


	//////////////////////////////
	cout << endl;
}



///////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////
// Class Function Definitions //
////////////////////////////////


//////// class Groups //////////

//constructor
Groups::Groups(int numElements)
	: N(numElements), groups(new group[numElements]) //dynamically allocate groupings array with the correct number of elements
{
	//each element i starts off as its own group with a size of 1
	for (int i = 0; i < numElements; ++i)
	{
		groups[i].link = i;
		groups[i].size = 0;
	}
}

//copyConstructor
Groups::Groups(const Groups& toCopy)
	: N(toCopy.N), groups(new group[toCopy.N]) //dynamically allocate groupings array with the correct number of elements
{
	for (int i = 0; i < N; ++i)
	{
		groups[i].link = toCopy.groups[i].link;
		groups[i].size = toCopy.groups[i].size;
	}
}

//destructor
Groups::~Groups()
{
	delete[] groups;
}

//function to find the group number of an element
int Groups::find_group(int i)
{
	//omitting bounds checking!

	//in the case that its group link connects to another sub-group
	if (groups[i].link != i)
		groups[i].link = find_group(groups[i].link);  //recursively changes links to directly link to the ultimate group number

	return groups[i].link;  //return ultimate group number
}

//function to combine two groups together
void Groups::combineGroups(int i, int j)
{
	//omitting bounds checking!

	//find their existing group numbers
	int grp_i = find_group(i);
	int grp_j = find_group(j);

	//if the two groups are not already connected
	if (grp_i != grp_j)
	{
		//if i's group is smaller, connects i's group to j's group
		if (groups[grp_i].size < groups[grp_j].size)
		{
			groups[grp_j].size += groups[grp_i].size; //increases the size of j's group appropriately
			groups[grp_i].link = grp_j; //set's i's group to link to j's group (making grp_j the ultimate group number)
		}

		else
		{
			groups[grp_i].size += groups[grp_j].size; //increases the size of i's group appropriately
			groups[grp_j].link = grp_i; //set's j's group to link to i's group (making grp_i the ultimate group number)
		}
	}
}



//////// class Edge //////////

//constructor
Edge::Edge(int i, int j, int c)
	: u(i), v(j), w(c)
{  }

//ranks edges based on their connectivity, NOT WEIGHTS!
bool operator<(const Edge& e1, const Edge& e2)
{
	return e1.u<e2.u ? true : e1.u>e2.u ? false : e1.v < e2.v ? true : false; //judges based on u and v (ie. w does NOT play a role in this comparison)
}



//////// class Graph //////////

//constructor
Graph::Graph(int N, int w_min, int w_max)
	: V(N), minW(w_min), maxW(w_max), connectedComponents(N)
{	}

//functions to add edges to the graph
bool Graph::addEdge(int i, int j, int c)
{
	if (i < 0 || i >= V || j < 0 || j >= V || i == j)
		return false;

	//attempt insertion of edge
	auto confirmation = edges.emplace(i, j, c);

	//if the edge was successfully inserted, insert in the opposite direction as well
	if (confirmation.second == true) //indicating the edge was inserted...
	{
		edges.emplace(j, i, c); //insert reverse edge
		connectedComponents.combineGroups(i, j); //record connection
	}

	//otherwise, the edge already existed, in which case we need to update the weight values in both directions
	else
	{
		confirmation.first->w = c;
		edges.find(Edge(j, i, c))->w = c;
	}

	return true;
}

bool Graph::addEdge(Edge e)
{
	if (e.u < 0 || e.u >= V || e.v < 0 || e.v >= V || e.u == e.v)
		return false;

	Edge rev(e.v, e.u, e.w);

	//attempt insertion of edge
	auto confirmation = edges.insert(e);

	//if the edge was successfully inserted, insert in the opposite direction as well
	if (confirmation.second == true) //indicating the edge was inserted...
	{
		edges.insert(rev); //insert reverse edge
		connectedComponents.combineGroups(e.v, e.u); //record connection
	}

	//otherwise, the edge already existed, in which case we need to update the weight values in both directions
	else
	{
		confirmation.first->w = e.w;
		edges.find(rev)->w = rev.w;
	}

	return true;
}

void Graph::addRandomEdges()
{
	//randomize what each element connects to and add the edge to the graph
	for (int i = 0; i < V; ++i)
	{
		addEdge(i, rand() % V, minW + rand() % (maxW - minW + 1)); //add edge from i to a random vertex with edge-weght in range [minW, maxW]
	}
}

void Graph::addRandomWeightEdge(int i, int j)
{
	//randomize edge weight
	addEdge(i, j, minW + rand() % (maxW - minW + 1)); //add edge from i to j with edge-weght in range [minW, maxW]
}

//misc public functions
void Graph::generateRandomConnectedGraph()
{
	int connectivityScore = (0.75 * log10(V) * V) / (1 + rand() % V); //connectivityScore will influence the probability of a fully connected graph vs. a sparsely connected graph
	for (int i = 0; i < connectivityScore; ++i)
	{
		addRandomEdges();  //randomize what each vertex connects to
	}

	set<int> disjointComponents; //a set to hold each disjoint connected component from our so-far generated graph

								 //discover various disjoint connected components
	for (int i = 0; i < V; ++i)
	{
		disjointComponents.insert(connectedComponents.find_group(i));
	}

	//we have two connected components that are disjoint
	if (disjointComponents.size() > 1)
	{
		//it1 starts at first element in the set, and it2 the second element
		auto it1 = disjointComponents.begin();
		auto it2 = it1;
		++it2;

		//connect disjoint components together
		for (; it2 != disjointComponents.end(); ++it1, ++it2)
			addRandomWeightEdge(*it1, *it2);

		if (rand() % 2) //with 50% chance
			addRandomWeightEdge(*disjointComponents.begin(), *it1); //connect last component with first
	}
}

int Graph::numEdges()
{
	return edges.size();
}

void Graph::saveGraph(string filename)
{

	ofstream fout(filename);

	if (!fout)
		cerr << endl << "ERROR OPENNING FILE!!!" << endl;

	fout << V;

	for (auto e : edges)
		fout << endl << e.u << "  " << e.v << "  " << e.w;

	fout.close();
}

void Graph::printGraph()
{
	cout << V;

	for (auto e : edges)
		cout << endl << e.u << "  " << e.v << "  " << e.w;
}



