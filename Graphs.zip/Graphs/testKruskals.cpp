#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <algorithm>

using namespace std;

void error(const char * msg)
{
    cerr << "Error: " << msg << endl;
    exit(-1);
}

struct Edge
{
    int v1;
    int v2;
    int w;
    Edge (int src, int dst, int weight): v1(src), v2(dst), w(weight){}
};

struct disjointSets
{
    int *parent, *rank;
    int size;
 
    // O(V) worst case because of calcultions below of largest growth factor
    disjointSets(int s)
    {
        size = s; // O(1)
        parent = new int[s+1]; // O(1)
        rank = new int[s+1]; // O(1)
 
        for (int i = 0; i <= s; ++i) // O(V)
        {
            rank[i] = 0; // O(1)
            parent[i] = i; // O(1)
        }
    }

    // O(V) because worst case parent would be traversed till 
    // end of size which is as large as # of Vertices
    int find(int node)
    {
        if (node != parent[node]) // O(1)
            parent[node] = find(parent[node]); // O(V) worst case
        return parent[node]; // O(1)
    }
 
    // O(V) worst case becaue used find, whose time complexity is described above
    void unionn(int treea, int treeb)
    {
        treea = find(treea), treeb = find(treeb); // both O(V)
 
        if (rank[treea] > rank[treeb]) // O(1)
            parent[treeb] = treea; // O(1)
        else
            parent[treea] = treeb; // O(1)
 
        if (rank[treea] == rank[treeb]) // O(1)
            ++rank[treeb]; // O(1)
    }
    
    ~disjointSets()
    {
	delete [] parent;
	delete [] rank;
    }
};

class Graph
{
    public:
    int sizeV;
    int totalcost;
    vector <Edge> MST;
    vector <Edge> edges;
    
    Graph(const char * fileName)
    {
        int value, src, dst, cost;
        ifstream in(fileName);
        if (in >> value) {
            sizeV = value;
        }
        else
            error("file not found");
        for ( ; ; )
        {
            if (in >> src >> dst >> cost)
            {
                addEdge(src, dst, cost);
            }
            else
                break;
        }
        in.close();
        totalcost = 0;
    }
    
    void addEdge(int u, int v, int w)
    {
        Edge * e = new Edge(u,v,w);
        edges.push_back(*e);
        delete e;
    }
    
    static bool edge_sorter(const Edge &a, const Edge &b)
    {
	    if (a.w == b.w)
	    {
    		if (a.v1 == b.v1 )
    			return a.v2< b.v2;
		    return a.v1 < b.v1;
        }
        return a.w < b.w;
    }
   
    // kruskals given a priority queue according to Mr.Klefstad is O(|V|log|E|) 
    // however my algorithm is O(|E|log|E|) because of the following calculations
    // as it is the largest growth factor in worst case considering Edges is 
    // always equal to or greater than Vertices
    vector<Edge> kruskals()
    {
        sort(edges.begin(), edges.end(), edge_sorter); // O(|E|log|E|) according to c++ library
        disjointSets d(sizeV); // O(V)
        for (vector<Edge>::iterator iter = edges.begin(); iter != edges.end(); ++iter) // O(E)
        {
            int a = iter->v1; // O(1)
	    int set_a = d.find(a); // O(V) explained above
            
            int b = iter->v2; // O(1)
	    int set_b = d.find(b); // O(V) explained above
            
            if (set_a != set_b) // O(1)
            {
                totalcost += iter->w; // O(1)
                MST.push_back(*iter); // O(1)
                d.unionn(set_a, set_b); // O(V) explained above
            }
        } // while for-loop would be O(VE) which is smaller growth factor than O(|E|log|E|) because
	  // need to account for the fact that Edges in worst case are much larger than # of Vertices
        return MST; // O(1)
    }
    
    friend ostream & operator << (ostream & out, Graph & g)
    {
        out << endl;
        for ( unsigned i=0; i < g.MST.size(); ++i )
            out << " " << g.edges[i].v1 << " - " << g.edges[i].v2 << " : " << g.edges[i].w << endl;
        out << "\nTotal cost of MST: " << g.totalcost << endl << endl;
        return out;	
    }
    
    ~Graph()
    {
	
    }
};

int main()
{
    Graph G("graph.txt");
    vector <Edge> MST = G.kruskals();
    cout << G;
    return 0;
}
